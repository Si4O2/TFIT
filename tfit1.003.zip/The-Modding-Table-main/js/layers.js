addLayer("ach", {
    name: "成就",
    symbol: "成就",
    position: -2,
    row: 0,
    color: "#f1c40f",
    type: "none",
    startData() { return { unlocked: true, points: new Decimal(0), ms: {} }},
    layerShown(){ return true },
    milestones: {
        0: {
            requirementDescription: "拥有成就 3",
            effectDescription: "觉得游戏速度很慢？获得成就3后按下按钮使游戏速度+1x（在常规速度下这个游戏是平衡的）",
            done() { return hasAchievement('ach', 13) }
        },
        1: {
            requirementDescription: "拥有成就 15",
            effectDescription: "觉得无限墙很大？获得成就15后按下按钮分别使游戏速度+2x +3x（过快的速度可能会使游戏失去平衡）",
            done() { return hasAchievement('ach', 31) }
        },
        2: {
            requirementDescription: "拥有成就 28",
            effectDescription: "达到无限（Ach.28）后，你可以按下按钮使游戏速度+5x",
            done() { return hasAchievement('ach', 47) }
        },
        3: {
    requirementDescription: "获得成就 54",
    effectDescription: "仰望星空 在宇宙中外还有无尽的奥秘 获得成就54后可使游戏速度+10x",
    done() { return hasAchievement('ach', 85) }
}
    },
    clickables: {
        11: {
            title() { return "加速 I (+1x)<br>" + (player.ach.ms?.ms0 ? "已开启" : "已关闭"); },
            canClick() { return hasAchievement('ach', 13); },
            onClick() { if (!player.ach.ms) player.ach.ms = {}; player.ach.ms.ms0 = !player.ach.ms.ms0; }
        },
        12: {
            title() { return "加速 II (+2x)<br>" + (player.ach.ms?.ms1_2 ? "已开启" : "已关闭"); },
            canClick() { return hasAchievement('ach', 31); },
            onClick() { if (!player.ach.ms) player.ach.ms = {}; player.ach.ms.ms1_2 = !player.ach.ms.ms1_2; }
        },
        13: {
            title() { return "加速 II (+3x)<br>" + (player.ach.ms?.ms1_3 ? "已开启" : "已关闭"); },
            canClick() { return hasAchievement('ach', 31); },
            onClick() { if (!player.ach.ms) player.ach.ms = {}; player.ach.ms.ms1_3 = !player.ach.ms.ms1_3; }
        },
        14: {
            title() { return "加速 III (+5x)<br>" + (player.ach.ms?.ms2 ? "已开启" : "已关闭"); },
            canClick() { return hasAchievement('ach', 47); },
            onClick() { if (!player.ach.ms) player.ach.ms = {}; player.ach.ms.ms2 = !player.ach.ms.ms2; }
        }, 
        15: {
            title() { return "加速 IV (+10x)<br>" + (player.ach.ms?.ms3 ? "已开启" : "已关闭"); },
            canClick() { return hasAchievement('ach', 85); },
            onClick() { if (!player.ach.ms) player.ach.ms = {}; player.ach.ms.ms3 = !player.ach.ms.ms3; }
        }
    },
    update(diff) {
    if (!player.ach.ms) player.ach.ms = {};
    let bonus = 0;
    if (player.ach.ms.ms0) bonus += 1;
    if (player.ach.ms.ms1_2) bonus += 2;
    if (player.ach.ms.ms1_3) bonus += 3;
    if (player.ach.ms.ms2) bonus += 5;
    if (player.ach.ms.ms3) bonus += 10;
    player.devSpeed = 1 + bonus;
},
    microtabs: {
        main: {
            "成就": {
                content: [
                    ["display-text", function() {
                        let achConfig = layers.ach.achievements;
                        let achIds = Object.keys(achConfig).filter(k => !isNaN(k));
                        let total = achIds.length;
                        let count = achIds.filter(id => hasAchievement('ach', id)).length;
                        return `<div style="font-size:20px;font-weight:bold;color:#f1c40f;margin-bottom:10px;">已完成成就：${count} / ${total}</div>`;
                    }],
                    "achievements"
                ]
            },
            "变速里程碑": {
                content: [
                    "milestones",
                    ["display-text", "<br><div style='color:#aaa;'>点击下方原版按钮切换速度加成</div>"],
                    ["row", [["clickable", 11]]],
                    ["row", [["clickable", 12], ["clickable", 13]]],
                    ["row", [["clickable", 14], ["clickable", 15]]]
                ]
            }
        }
    },
    achievements: {
        rows: 9, cols: 7,
        11: { name: "1.一百万", tooltip: "达到 1,000,000 分", done() { return player.points.gte(1e6) }, unlocked: () => true },
        12: { name: "2.100级", tooltip: "红色乘数工厂达到 100 级", done() { return _getBuyLvl(11).gte(100) }, unlocked: () => true },
        13: { name: "3.转生", tooltip: "完成一次转生（pm > 1）", done() { return getPrestigeMult().gt(1) }, unlocked: () => true },
        14: { name: "4.RGB", tooltip: "购买一次蓝色乘数工厂", done() { return _getBuyLvl(22).gte(1) }, unlocked: () => true },
        15: { name: "5.超过一千", tooltip: "任意乘数大于 1000", done() { return multiplierOrder.some(k => getLayerMultiplier(k).gt(1000)) }, unlocked: () => true },
        16: { name: "6.200级", tooltip: "红色乘数工厂达到 200 级", done() { return _getBuyLvl(11).gte(200) }, unlocked: () => true },
        17: { name: "7.准备大促销", tooltip: "声望乘数达到 1000", done() { return getPrestigeMult().gte(1000) }, unlocked: () => true },
        21: { name: "8.有力气", tooltip: "普通指数达到 1.1", done() { return getGeneralExponent().gte(1.1) }, unlocked: () => true },
        22: { name: "9.拾色之旅", tooltip: "白色乘数工厂达到 1 级", done() { return _getBuyLvl(25).gte(1) }, unlocked: () => true },
        23: { name: "10.大！促！销！", tooltip: "任意一个晋升购买项达到一级<br><br>奖励：每种颜色乘数获取 x1.05", done() { return [1,2,3,4].some(i => getPrmLvl(i).gte(1)) }, unlocked: () => true },
        24: { name: "11.百产", tooltip: "任意一种颜色乘数获取 >= 100/s", done() { return multiplierOrder.some(k => getMultiplierGain(k).gte(100)) }, unlocked: () => true },
        25: { name: "12.大乘数", tooltip: "声望乘数 pm 达到 1,000,000", done() { return getPrestigeMult().gte(1e6) }, unlocked: () => true },
        26: { name: "13.五小时后", tooltip: "任意一个晋升项达到 5 级<br><br>奖励：所有颜色乘数获取 x1.05", done() { return [1,2,3,4].some(i => getPrmLvl(i).gte(5)) }, unlocked: () => true },
        27: { name: "14.更有力气了", tooltip: "普通指数达到 1.2<br><br>奖励：可以最大购买各种乘数购买项", done() { return getGeneralExponent().gte(1.2) }, unlocked: () => true },
        31: { name: "15.20%无限", tooltip: "无限进度达到 20%<br><br>奖励：所有颜色乘数获取速度 x1.1", done() { return player.points.gte("4.47655e61") }, unlocked: () => true },
        32: { name: "16.超多经验", tooltip: "晋升经验达到 1,000,000<br><br>奖励：晋升4效果 x1.03", done() { return player.prm && player.prm.points.gte(1e6) }, unlocked: () => true },
        33: { name: "17.好样的", tooltip: "四个晋升项目均达到 20 级<br><br>奖励：晋升4指数+0.04", done() { return [1,2,3,4].every(i => getPrmLvl(i).gte(20)) }, unlocked: () => true },
        34: { name: "18.无声望推进", tooltip: "在不进行声望的情况下获得 1e50 分<br><br>奖励：晋升3效果底数+0.05，pm获取^1.01", done() { return getPrestigeMult().eq(1) && player.pt && player.pt.pe.eq(0) && player.points.gte("1e50") }, unlocked: () => true },
        35: { name: "19.power fulllllll", tooltip: "普通指数达到 1.3<br><br>奖励：普通指数+0.01", done() { return getGeneralExponent().gte(1.3) }, unlocked: () => true },
        36: { name: "20.Googol！", tooltip: "达到 1e100 分。你需要放置一段时间。<br><br>奖励：每一个成就为晋升3效果底数提供+0.01", done() { return player.points.gte("1e100") }, unlocked: () => true },
        37: { name: "21.500级", tooltip: "红色乘数工厂达到 500 级<br><br>奖励：红色乘数工厂价格倍率基础-0.03", done() { return _getBuyLvl(11).gte(500) }, unlocked: () => true },
        41: { name: "22.轻松百万", tooltip: "在不转生情况下进行晋升并获取1000000晋升经验<br><br>奖励：晋升购买项价格基础-0.12", done() { return player.pt && player.pt.pm.eq(1) && player.pt.pe.eq(0) && getAscensionExpGain().gte(1e6) }, unlocked: () => true },
        42: { name: "23.power attack！", tooltip: "普通指数达到 1.55<br><br>奖励：普通指数+0.02", done() { return getGeneralExponent().gte(1.55) }, unlocked: () => true },
        43: { name: "24.半程无限", tooltip: "无限进度达到50%（分数达到 2^512）", done() { return player.points.gte(new Decimal(2).pow(512)) }, unlocked: () => true },
        44: { name: "25.太爽了", tooltip: "前三种颜色乘数工厂均达到600级以上<br><br>奖励：前三种颜色乘数获取^1.03", done() { return _getBuyLvl(11).gte(600) && _getBuyLvl(12).gte(600) && _getBuyLvl(13).gte(600) }, unlocked: () => true },
        45: { name: "26.rainbow！", tooltip: "每种颜色乘数产量达到 10000/s<br><br>奖励：每种乘数获取速度^1.01", done() { return multiplierOrder.every(k => getMultiplierGain(k).gte(10000)) }, unlocked: () => true },
        46: { name: "27.有力气^2", tooltip: "pe 达到 1<br><br>奖励：pe加成pm获取（在1以后）", done() { return player.pt && player.pt.pe.gte(1) }, unlocked: () => true },
        47: { name: "28.无限！", tooltip: "达到 1.7976e308 分", done() { return player.points.gte("1.7976e308") }, unlocked: () => true },
        51: { name: "29.Qol！", tooltip: "开启所有乘数工厂自动购买<br><br>奖励：红色乘数工厂和g1效率*1.2<br>现在购买颜色乘数工厂不再消耗分数", done() { return player.auto && [11, 12, 13, 14, 15, 21, 22, 23, 24, 25].every(id => player.auto[id] === true); }, unlocked: () => true },
        52: { name: "30.e616？", tooltip: "达到两次无限", done() { return player.inf && player.inf.infinity.gte(2); }, unlocked: () => true },
        53: { name: "31.数量很多", tooltip: "达到五次无限<br><br>奖励：IP获取x2", done() { return player.inf && player.inf.infinity.gte(5); }, unlocked: () => true },
        54: { name: "32.很有挑战性", tooltip: "解锁无限挑战", done() { return hasUpgrade('inf', 22); }, unlocked: () => true },
        55: { name: "33.第一个问题解决了", tooltip: "完成无限挑战 1", done() { return hasChallenge('inf', 11); }, unlocked: () => true },
        56: { name: "34.下一世代", tooltip: "拥有 10 gp", done() { return player.inf && player.inf.gp.gte(10); }, unlocked: () => true },
        57: { name: "35.生产更多", tooltip: "拥有 1000 gp<br><br>奖励：g1效率 * 1.2", done() { return player.inf && player.inf.gp.gte(1000); }, unlocked: () => true },
        61: { name: "36.反物质维度", tooltip: "购买 1 个 g2", done() { return player.inf && player.inf.generators[12].gte(1); }, unlocked: () => true },
        62: { name: "37.九分之四", tooltip: "完成无限挑战 4<br><br>奖励：IP获取 * 2.25", done() { return hasChallenge('inf', 21); }, unlocked: () => true },
        63: { name: "38.再多一点qol", tooltip: "解锁晋升自动化", done() { return hasUpgrade('inf', 31); }, unlocked: () => true },
        64: { name: "39.字节无限", tooltip: "达到 256 无限", done() { return player.inf && player.inf.infinity.gte(256); }, unlocked: () => true },
        65: { name: "40.击碎它！", tooltip: "打破无限<br><br>奖励：点数获取 * 10<br>每个无限升级的分数增益由 ×2 提升为 ×10", done() { return player.inf && player.inf.challenge_broken; }, unlocked: () => true },
        66: { name: "41.更上一层楼", tooltip: "达到 1e1000 分数<br><br>奖励：无限获取 ×1.5", done() { return player.points.gte("1e1000") }, unlocked: () => true },
        67: { name: "42.powerfully", tooltip: "获得 1e20 gp", done() { return player.inf && player.inf.gp.gte("1e20") }, unlocked: () => true },
        71: { name: "43.千万强化", tooltip: "达到 10002221 IP<br><br>奖励：十种颜色乘数工厂获得 +12 免费等级（不影响价格）", done() { return player.inf && player.inf.points.gte(10002221) }, unlocked: () => true },
        72: { name: "44.第四生成器", tooltip: "购买一个 g4", done() { return player.inf && player.inf.generators[14].gte(1); }, unlocked: () => true },
        73: { name: "45.两千指数", tooltip: "达到 1e2000 分数<br><br>奖励：IP获取 ×1.2", done() { return player.points.gte("1e2000") }, unlocked: () => true },
        74: { name: "46.莫比乌斯", tooltip: "达到 5000 无限<br><br>奖励：无限获取 ×1.1", done() { return player.inf && player.inf.infinity.gte(5000) }, unlocked: () => true },
        75: { name: "47.无限经验", tooltip: "达到 1.8e308 晋升经验<br><br>奖励：晋升经验获取 ^1.05", done() { return player.prm && player.prm.points.gte("1.8e308") }, unlocked: () => true },
        76: { name: "48.通胀时代", tooltip: "达到 1e3080 分数<br><br>奖励：所有颜色乘数工厂、生成器效率、IP 和无限获取 ×2", done() { return player.points.gte("1e3080") }, unlocked: () => true },
        77: { name: "49.一次一百万", tooltip: "单次无限重置中获取的 IP 达到 1,000,000", done() { return player.inf && player.inf.lastIPGain && player.inf.lastIPGain.gte(1e6) }, unlocked: () => true },
        81: { name: "50.这真的合理吗", tooltip: "达到 1e3500 分数<br><br>奖励：IP 获取 ×1.5", done() { return player.points.gte("1e3500") }, unlocked: () => true },
        82: { name: "51.你能刚好拥有50个吗？", tooltip: "获得 50 个成就（任意 50 个）<br><br>奖励：每个已完成的成就加成所有生成器效果 ×1.02<br>公式：1.02^已完成成就数", done() { return getAchievementsCompleted() >= 50 }, unlocked: () => true },
        83: { name: "52.IP越来越大", tooltip: "达到 1e15 IP", done() { return player.inf && player.inf.points.gte("1e15") }, unlocked: () => true },
        84: { name: "53.这生成器太有力量了", tooltip: "生成器指数达到 1", done() { return getEffectiveGE().gte(1) }, unlocked: () => true },
        85: { name: "54.仰望星空", tooltip: "解锁星星（购买 u91）<br><br>奖励：无限获取 ×1.5", done() { return hasUpgrade('inf', 91) }, unlocked: () => true },
        86: { name: "55.漂亮的星尘", tooltip: "获得 1000 星尘", done() { return player.inf && player.inf.stardust.gte(1000) }, unlocked: () => true },
        87: { name: "56.疯狂通胀", tooltip: "获得 1e63 IP", done() { return player.inf && player.inf.points.gte("1e63") }, unlocked: () => true },
        91: { name: "57.又变快了", tooltip: "获得 1e93 IP", done() { return player.inf && player.inf.points.gte("1e93") }, unlocked: () => true },
        92: { name: "58.星星成长", tooltip: "达到 16 颗星星", done() { return player.inf && player.inf.stars.gte(16) }, unlocked: () => true },
        93: { name: "59.半程永恒", tooltip: "获得 1.34e154 IP", done() { return player.inf && player.inf.points.gte("1.34e154") }, unlocked: () => true },
        94: { name: "60.永远...的...终点...？", tooltip: "达到 1.8e308 IP", done() { return player.inf && player.inf.points.gte("1.8e308") }, unlocked: () => true },
    },
    tabFormat: [
        ["display-text", function() { return getPointsDisplay() }],
        ["microtabs", "main"]
    ],
})

addLayer("基础", {
    name: "sideLayer1",
    position: -1,
    row: 0,
    symbol() {return '↓ 基础 ↓'},
    symbolI18N() {return '↓ layer 1 ↓'},
    small: true,
    nodeStyle: {"font-size": "15px", "height": "30px"},
    startData() { return { unlocked: true, points: new Decimal(0) }},
    color: "#fefefe",
    type: "none",
    tooltip(){return false},
    layerShown(){return layerDisplayTotal(['p', 'pt'])},
	tabFormat: [["display-text", function() { return getPointsDisplay() }]],
})

addLayer("auto", {
    name: "自动化",
    symbol: "自动化",
    position: -3,
    row: 0,
    color: "#fefefe",
    type: "none",
    startData() { return { 
        unlocked: true, points: new Decimal(0),
        11: false, 12: false, 13: false, 14: false, 15: false,
        21: false, 22: false, 23: false, 24: false, 25: false,
        31: false, 32: false
    }},
    layerShown() { return hasUpgrade('inf', 11); }, 
    update(diff) {
        if (player.inf && player.inf.upgrades && player.inf.upgrades.includes(21)) {
            if (player.auto && player.auto[31]) {
                ensurePrestigeData();
                if (canPrestige()) {
                    let gain = getPrestigeGain();
                    if (player.pt.pm.lt(gain.pm) || player.pt.pe.lt(gain.pe)) {
                        doPrestigeReset();
                    }
                }
            }
        }
        if (player.inf && player.inf.upgrades && player.inf.upgrades.includes(31)) {
            if (player.auto && player.auto[32]) {
                ensureAscensionData();
                let gain = getAscensionExpGain().mul(diff);
                player.prm.points = player.prm.points.add(gain);
                
                let inIC32 = inChallenge('inf', 32);
                let inIC1 = inChallenge('inf', 11);
                
                let base = (typeof hasAchievement === 'function' && hasAchievement('ach', 41)) ? new Decimal(1.88) : new Decimal(2);
                if (hasChallenge('inf', 32)) base = base.sub(0.13);
                let baseLog = base.log10();
                let maxLvl;
                if (player.prm.points.gt(0)) {
                    maxLvl = player.prm.points.log10().div(baseLog).floor().add(1);
                } else {
                    maxLvl = new Decimal(0);
                }
                if (maxLvl.lt(0)) maxLvl = new Decimal(0);
                
                for (let i = 1; i <= 4; i++) {
                    if (inIC32) break;
                    if (inIC1 && (i === 2 || i === 4)) continue;
                    let lvl = getPrmLvl(i);
                    if (maxLvl.gt(lvl)) player.prm.buyables[i] = maxLvl;
                }
            }
        }
    },
    clickables: {
        11: {
            title() { return "红色乘数工厂"; },
            display() { return `红色乘数工厂<br>自动购买已${player.auto[11] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[11] = !player.auto[11]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        12: {
            title() { return "橙色乘数工厂"; },
            display() { return `橙色乘数工厂<br>自动购买已${player.auto[12] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[12] = !player.auto[12]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        13: {
            title() { return "黄色乘数工厂"; },
            display() { return `黄色乘数工厂<br>自动购买已${player.auto[13] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[13] = !player.auto[13]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        14: {
            title() { return "绿色乘数工厂"; },
            display() { return `绿色乘数工厂<br>自动购买已${player.auto[14] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[14] = !player.auto[14]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        15: {
            title() { return "蓝绿色乘数工厂"; },
            display() { return `蓝绿色乘数工厂<br>自动购买已${player.auto[15] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[15] = !player.auto[15]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        21: {
            title() { return "青色乘数工厂"; },
            display() { return `青色乘数工厂<br>自动购买已${player.auto[21] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[21] = !player.auto[21]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        22: {
            title() { return "蓝色乘数工厂"; },
            display() { return `蓝色乘数工厂<br>自动购买已${player.auto[22] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[22] = !player.auto[22]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        23: {
            title() { return "紫色乘数工厂"; },
            display() { return `紫色乘数工厂<br>自动购买已${player.auto[23] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[23] = !player.auto[23]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        24: {
            title() { return "粉色乘数工厂"; },
            display() { return `粉色乘数工厂<br>自动购买已${player.auto[24] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[24] = !player.auto[24]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        25: {
            title() { return "白色乘数工厂"; },
            display() { return `白色乘数工厂<br>自动购买已${player.auto[25] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            canClick() { return true; },
            onClick() { player.auto[25] = !player.auto[25]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        31: {
            title() { return "自动声望"; },
            display() { return `自动声望<br>已${player.auto[31] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            unlocked() { return hasUpgrade('inf', 21); },
            canClick() { return true; },
            onClick() { player.auto[31] = !player.auto[31]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        },
        32: {
            title() { return "自动晋升"; },
            display() { return `自动晋升<br>已${player.auto[32] ? "<span style='color:#7fff7f;'>开启</span>" : "<span style='color:#ff7f7f;'>关闭</span>"}`; },
            unlocked() { return hasUpgrade('inf', 31); },
            canClick() { return true; },
            onClick() { player.auto[32] = !player.auto[32]; },
            style() { return { "width": "150px", "height": "60px", "font-size": "14px", "color": "#fefefe", "background-color": "#1a1a1a", "border": "2px solid #555", "border-radius": "8px" }; }
        }
    },
    tabFormat: [
        ["display-text", function() { return getPointsDisplay() }],
        ["display-text", "<div style='color:#fefefe; font-size:18px; margin-bottom:10px;'>点击以切换自动购买开关</div>"],
        ["row", [["clickable", 11], ["clickable", 12], ["clickable", 13], ["clickable", 14], ["clickable", 15]]],
        ["row", [["clickable", 21], ["clickable", 22], ["clickable", 23], ["clickable", 24], ["clickable", 25]]],
        ["display-text", "<br>"],
        ["row", [["clickable", 31], ["clickable", 32]]]
    ]
})

addLayer("infsmall", {
    name: "infsmall",
    position: -1,
    row: 3,
    symbol() {return '↓ 无限 ↓'},
    symbolI18N() {return '↓ Infinity ↓'},
    small: true,
    nodeStyle: {"font-size": "15px", "height": "30px"},
    startData() { return { unlocked: true, points: new Decimal(0) } },
    color: "#fefefe",
    type: "none",
    tooltip(){return false},
    layerShown(){ return hasAchievement('ach', 47); },
    tabFormat: []
})

var _pBuyables = { rows: 2, cols: 5 };
for (let k of multiplierOrder) {
    let cfg = buyableConfig[k];
    let key = k;
    let bid = cfg.id;

    _pBuyables[bid] = {
        title: multiplierNames[key] + "工厂",
        cost(x) { return getBuyablePrice(key, x); },
        display() {
            let lvl = _getBuyLvl(bid);
            let eff = getMultiplierGain(key);
            let price = getBuyablePrice(key, lvl);
            let c = multiplierColors[key];

return `<div>等级：${formatWhole(lvl)}</div>
                <div>每秒 +${format(eff)} ${multiplierNames[key]}</div>
                <div>价格：${format(price)} 点数</div>`;
        },
        canAfford() {
            if (inChallenge('inf', 33) && bid > 14) return false;
            let lvl = _getBuyLvl(bid);
            let price = getBuyablePrice(key, lvl);
            return player.points.gte(price);
        },
        buy() {
            if (inChallenge('inf', 33) && bid > 14) return;
            let lvl = _getBuyLvl(bid);
            let price = getBuyablePrice(key, lvl);
            if (!player.points.gte(price)) return;
            let noCost = (typeof hasAchievement === 'function' && hasAchievement('ach', 51));
            if (typeof hasAchievement === 'function' && hasAchievement('ach', 27)) {
                let count = 0;
                while (player.points.gte(price) && count < 10000) {
                    if (!noCost) player.points = player.points.sub(price);
                    lvl = lvl.add(1);
                    count++;
                    price = getBuyablePrice(key, lvl);
                }
                _setBuyLvl(bid, lvl);
            } else {
                if (!noCost) player.points = player.points.sub(price);
                _setBuyLvl(bid, lvl.add(1));
            }
        },
    };
}

addLayer("p", {
    name: "乘数",
    symbol: "乘数",
    symbolI18N: "Prestige",
    position: 0,
    row: 0,
    startData() { return {
        unlocked: true, points: new Decimal(0),
        red: new Decimal(1), orange: new Decimal(1), yellow: new Decimal(1), green: new Decimal(1), teal: new Decimal(1),
        cyan: new Decimal(1), blue: new Decimal(1), purple: new Decimal(1), pink: new Decimal(1), white: new Decimal(1),
        buyables: { 11: new Decimal(0), 12: new Decimal(0), 13: new Decimal(0), 14: new Decimal(0), 15: new Decimal(0), 21: new Decimal(0), 22: new Decimal(0), 23: new Decimal(0), 24: new Decimal(0), 25: new Decimal(0) },
    }},
    color: "#ffffff",
    type: "none",
    buyables: _pBuyables,
    clickables: {
        11: {
            unlocked() { return player.prm && (player.prm.ascended || player.prm.points.gt(0) || [1,2,3,4].some(i => getPrmLvl(i).gt(0))); },
            title() { return "进行声望"; },
            display() {
                ensurePrestigeData();
                let gain = getPrestigeGain();
                let can = canPrestige();
                let headerColor = can ? "#31aeb0" : "#7f7f7f";
                let need = Decimal.max(PRESTIGE_THRESHOLD, player.pt.lastScore);
                return `<div style="font-size:22px;font-weight:bold;color:${headerColor};margin-bottom:8px;">进行声望</div>
                        <div style="font-size:16px;margin:2px 0;">声望乘数将变为：<span style="color:${prestigeMultColor};font-weight:bold;">x${format(gain.pm)}</span></div>
                        <div style="font-size:16px;margin:2px 0;">声望指数将变为：<span style="color:${generalExponentColor};font-weight:bold;">${format(gain.pe)}</span></div>
                        <div style="font-size:13px;color:${can ? "#9fff9f" : "#ff9f9f"};margin-top:8px;">${can ? "点击进行声望" : "下一次声望需要 " + format(need) + " 分数"}</div>`;
            },
            canClick() { return canPrestige(); },
            onClick() { doPrestigeReset(); },
            style() {
                let can = canPrestige();
                return {
                    "width": "320px", "height": "130px", "min-height": "130px", "border-radius": "10px",
                    "border": "2px solid " + (can ? "#31aeb0" : "#555555"),
                    "background-color": can ? "#1b3a3b" : "#2a2a2a", "color": "#ffffff",
                    "cursor": can ? "pointer" : "not-allowed", "opacity": can ? "1" : "0.7",
                    "padding": "8px", "text-align": "center", "transition": "background-color 0.15s, border-color 0.15s",
                };
            },
        },
    },
    update(diff) {
        ensureMultiplierData();
        ensurePrestigeData();
        multiplierProduction(diff);
        if (!player.inf || !player.inf.challenge_broken) {
            if (player.points && player.points.gt(MAX_POINTS)) {
                player.points = new Decimal(MAX_POINTS);
            }
        }
        ensureInfinityData();
        if (player.inf.upgrades.includes(11)) {
            let noCost = (typeof hasAchievement === 'function' && hasAchievement('ach', 51));
            for (let k of multiplierOrder) {
                let bid = buyableConfig[k].id;
                if (player.auto[bid]) {
                    if (inChallenge('inf', 33) && bid > 14) continue;
                    let lvl = _getBuyLvl(bid);
                    let price = getBuyablePrice(k, lvl);
                    if (player.points.gte(price)) {
                        let count = 0;
                        while (player.points.gte(price) && count < 10000) {
                            if (!noCost) player.points = player.points.sub(price);
                            lvl = lvl.add(1);
                            count++;
                            price = getBuyablePrice(k, lvl);
                        }
                        _setBuyLvl(bid, lvl);
                    }
                }
            }
        }
    },
    tabFormat: [
        ["display-text", function() { return getPointsDisplay() }],
        ["display-text", function() { return getMultiplierList() }],
        "buyables",
        ["clickable", 11],
    ],
    layerShown(){return true},
})

addLayer("pt", {
    name: "声望",
    symbol: "声望",
    position: 0,
    row: 1,
    color: "#31aeb0",
    type: "none",
    startData() { return { unlocked: true, points: new Decimal(0), pm: new Decimal(1), pe: new Decimal(0), lastScore: new Decimal(0) }},
    layerShown(){
        ensurePrestigeData();
        return player.points.gte(1e10) || player.pt.pm.gt(1) || isAscensionUnlocked();
    },
    clickables: {
        11: {
            title() { return "进行声望"; },
            display() {
                ensurePrestigeData();
                let gain = getPrestigeGain();
                let can = canPrestige();
                let headerColor = can ? "#31aeb0" : "#7f7f7f";
                let need = Decimal.max(PRESTIGE_THRESHOLD, player.pt.lastScore);
                return `<div style="font-size:22px;font-weight:bold;color:${headerColor};margin-bottom:8px;">进行声望</div>
                        <div style="font-size:16px;margin:2px 0;">声望乘数将变为：<span style="color:${prestigeMultColor};font-weight:bold;">x${format(gain.pm)}</span></div>
                        <div style="font-size:16px;margin:2px 0;">声望指数将变为：<span style="color:${generalExponentColor};font-weight:bold;">${format(gain.pe)}</span></div>
                        <div style="font-size:13px;color:${can ? "#9fff9f" : "#ff9f9f"};margin-top:8px;">${can ? "点击进行声望" : "下一次声望需要 " + format(need) + " 分数"}</div>`;
            },
            canClick() { return canPrestige(); },
            onClick() { doPrestigeReset(); },
            style() {
                let can = canPrestige();
                return {
                    "width": "320px", "height": "130px", "min-height": "130px", "border-radius": "10px",
                    "border": "2px solid " + (can ? "#31aeb0" : "#555555"),
                    "background-color": can ? "#1b3a3b" : "#2a2a2a", "color": "#ffffff",
                    "cursor": can ? "pointer" : "not-allowed", "opacity": can ? "1" : "0.7",
                    "padding": "8px", "text-align": "center", "transition": "background-color 0.15s, border-color 0.15s",
                };
            },
        },
    },
    tabFormat: [
    ["display-text", function() { return getPointsDisplay() }],
    ["display-text", function() {
        ensurePrestigeData();
        let exp = new Decimal(1).add(player.pt.pe);
        return `<div style="font-size:22px;color:#31aeb0;font-weight:bold;margin-bottom:8px;">声望</div>
                <div style="font-size:18px;">声望乘数 pm：<span style="color:${prestigeMultColor};font-weight:bold;">x${format(player.pt.pm)}</span></div>
                <div style="font-size:18px;">声望指数 pe：<span style="color:${generalExponentColor};font-weight:bold;">${format(player.pt.pe)}</span></div>
                <div style="font-size:16px;color:#aaaaaa;">普通指数 = 1 + pe = ${format(exp)}</div>
                <div style="font-size:14px;color:#888888;">上次声望分数：${format(player.pt.lastScore)}</div>
                <div style="font-size:14px;color:#888888;">声望门槛：${format(PRESTIGE_THRESHOLD)}</div>
                <div style="margin-top:12px;"></div>`;
    }],
    ["clickable", 11],
],
})

var _prmBuyables = { rows: 1, cols: 4 };
var prmInfo = {
    1: { name: "效率提升", desc: "提升十种颜色乘数的基础效率" },
    2: { name: "速度增长", desc: "提升十种颜色乘数获取速度" },
    3: { name: "分数激增", desc: "每级使分数获取提升" },
    4: { name: "晋升力量", desc: "加成前三项晋升效果" },
};

function getPrmEffectDisplay(id) {
    if (id === 1) return `基础效率 x${format(getPrm1Effect())}`;
    if (id === 2) return `获取速度 x${format(getPrm2Effect())}`;
    if (id === 3) return `分数获取 x${format(getPrm3Effect())}`;
    if (id === 4) return `前三项加成 x${format(getPrm4Effect())}`;
}

for (let i = 1; i <= 4; i++) {
    let pid = i;
    _prmBuyables[pid] = {
        title: prmInfo[pid].name,
        cost(x) { return getPrmPrice(x); },
        display() {
            ensureAscensionData();
            let lvl = getPrmLvl(pid);
            let price = getPrmPrice(lvl);
            return `<div style="font-size:12px;color:#aaa;">${prmInfo[pid].desc}</div>
                <div>等级：${formatWhole(lvl)}</div>
                <div>效果：${getPrmEffectDisplay(pid)}</div>
                <div>价格：${format(price)} 晋升经验</div>`;
        },
        canAfford() {
            if (inChallenge('inf', 11) && (pid === 2 || pid === 4)) return false;
            if (inChallenge('inf', 32)) return false;
            ensureAscensionData();
            let lvl = getPrmLvl(pid);
            let price = getPrmPrice(lvl);
            return player.prm && player.prm.points.gte(price);
        },
        buy() {
            if (inChallenge('inf', 11) && (pid === 2 || pid === 4)) return;
            if (inChallenge('inf', 32)) return;
            ensureAscensionData();
            let lvl = getPrmLvl(pid);
            let price = getPrmPrice(lvl);
            if (!player.prm || !player.prm.points.gte(price)) return;
            player.prm.points = player.prm.points.sub(price);
            player.prm.buyables[pid] = lvl.add(1);
        },
    };
}

addLayer("prm", {
    name: "晋升",
    symbol: "晋升",
    symbolI18N: "Ascension",
    position: 0,
    row: 2,
    color: "#4bdc13",
    type: "none",
    resource: "晋升经验",
    startData() { return { unlocked: true, points: new Decimal(0), buyables: { 1: new Decimal(0), 2: new Decimal(0), 3: new Decimal(0), 4: new Decimal(0) } }},
    layerShown(){
        ensureAscensionData();
        return isAscensionUnlocked();
    },
    clickables: {
        11: {
            title() { return "进行晋升"; },
            display() {
                ensureAscensionData();
                let can = canAscend();
                let headerColor = can ? "#4bdc13" : "#7f7f7f";
                return `<div style="font-size:22px;font-weight:bold;color:${headerColor};margin-bottom:8px;">进行晋升</div>
                        <div style="font-size:14px;margin:2px 0;color:#aaa;">重置声望与分数</div>
                        <div style="font-size:13px;color:${can ? "#9fff9f" : "#ff9f9f"};margin-top:8px;">${can ? "点击进行晋升" : "需要 max(pm, 待获取pm) 达到 1000"}</div>`;
            },
            canClick() { return canAscend(); },
            onClick() { doAscend(); },
            style() {
                let can = canAscend();
                return {
                    "width": "320px", "height": "130px", "min-height": "130px", "border-radius": "10px",
                    "border": "2px solid " + (can ? "#4bdc13" : "#555555"),
                    "background-color": can ? "#1b3a1b" : "#2a2a2a", "color": "#ffffff",
                    "cursor": can ? "pointer" : "not-allowed", "opacity": can ? "1" : "0.7",
                    "padding": "8px", "text-align": "center", "transition": "background-color 0.15s, border-color 0.15s",
                };
            },
        },
    },
    buyables: _prmBuyables,
    tabFormat: [
        ["display-text", function() { return getPointsDisplay() }],
        "main-display",
        ["clickable", 11],
        ["row", [["buyable", 1], ["buyable", 2], ["buyable", 3], ["buyable", 4]]],
        ["display-text", function() {
            ensureAscensionData();
            let gain = getAscensionExpGain();
            let can = canAscend();
            return `<div style="font-size:24px;margin-top:20px;color:${can ? "#4bdc13" : "#7f7f7f"};font-weight:bold;">+${format(gain)} 晋升经验</div>`;
        }]
    ],
})

var _infBuyables = {};
var genIds = [11, 12, 13, 14, 15, 21, 22, 23, 24, 25];
var genPrices = {
    11: { base: 1, grow: 1 }, 12: { base: 2, grow: 2 }, 13: { base: 5, grow: 3 },
    14: { base: 8, grow: 4 }, 15: { base: 13, grow: 6 }, 21: { base: 20, grow: 8 },
    22: { base: 30, grow: 10 }, 23: { base: 45, grow: 15 }, 24: { base: 60, grow: 20 }, 25: { base: 75, grow: 25 }
};

function getInfBuyablePrice(pid, lvl) {
    let p = genPrices[pid];
    return new Decimal(10).pow(p.base).mul(new Decimal(10).pow(p.grow).pow(lvl));
}

for (let i = 0; i < 10; i++) {
    let pid = genIds[i];
    let genIndex = i + 1;
    
    _infBuyables[pid] = {
        title: "生成器 g" + genIndex,
        cost(x) { return getInfBuyablePrice(pid, x); },
        display() {
            ensureInfinityData();
            let lvl = player.inf.generators[pid] || new Decimal(0);
            let amount = player.inf.gens[pid] || new Decimal(0);
            let price = getInfBuyablePrice(pid, lvl);
            
            let effStr = "";
            if (lvl.gt(0)) {
                let eff = amount.mul(new Decimal(2).pow(lvl.sub(1)));
                if (genIndex === 1) {
                    if (hasAchievement('ach', 51)) eff = eff.mul(1.2);
                    if (hasAchievement('ach', 57)) eff = eff.mul(1.2);
                    if (player.inf.upgrades.includes(23)) eff = eff.mul(5);
                    if (player.inf.upgrades.includes(24)) eff = eff.mul(player.inf.gp.add(10).log10());
                    if (player.inf.upgrades.includes(32)) eff = eff.mul(new Decimal(1.5).mul(player.inf.points.add(10).log10()));
                    if (player.inf.upgrades.includes(42)) {
                        let challCount = getChallengesCompleted();
                        eff = eff.mul(Decimal.pow(32, 0.1 + challCount / 10));
                    }
                    if (player.inf.upgrades.includes(54)) eff = eff.mul(10);
                    if (player.inf.upgrades.includes(63)) {
                        let g3Count = player.inf.generators[13] || new Decimal(0);
                        let u63Eff;
                        if (g3Count.lte(0)) u63Eff = new Decimal(1);
                        else if (g3Count.lte("1e10")) u63Eff = g3Count.pow(2).max(1);
                        else u63Eff = new Decimal("1e20").mul(g3Count.sub("1e10"));
                        eff = eff.mul(u63Eff);
                    }
                } else if (genIndex === 2) {
                    if (player.inf.upgrades.includes(25)) eff = eff.mul(3);
                    if (player.inf.upgrades.includes(33)) eff = eff.mul(new Decimal(1.2).mul(player.inf.points.add(10).log10()));
                    if (player.inf.upgrades.includes(34)) eff = eff.mul(new Decimal(1).add(player.inf.infinity.pow(0.5)));
                    if (player.inf.upgrades.includes(42)) {
                        let challCount = getChallengesCompleted();
                        eff = eff.mul(Decimal.pow(22.5, 0.1 + challCount / 10));
                    }
                } else if (genIndex === 3) {
                    if (player.inf.upgrades.includes(51)) {
                        let inf = player.inf.infinity || new Decimal(0);
                        eff = eff.mul(new Decimal(1.05).mul(inf.add(1).log10()));
                    }
                    if (player.inf.upgrades.includes(62)) {
                        let g2Count = player.inf.generators[12] || new Decimal(0);
                        eff = eff.mul(g2Count.max(1));
                    }
                } else if (genIndex === 4) {
                    if (player.inf.upgrades.includes(81)) {
                        let g3Count = player.inf.generators[13] || new Decimal(0);
                        eff = eff.mul(new Decimal(1.1).mul(g3Count.add(1)));
                    }
                }
                // u11 扩展：根据星尘购买项 41 的等级，生效至 g(1+等级)
                if (player.inf.upgrades.includes(11) && new Decimal(genIndex - 1).lte(getStardustBuyableLvl(41))) {
                    eff = eff.mul(player.inf.infinity.max(1));
                }
                if (typeof hasAchievement === 'function' && hasAchievement('ach', 76)) eff = eff.mul(2);
                if (typeof hasAchievement === 'function' && hasAchievement('ach', 82)) {
                    eff = eff.mul(new Decimal(1.02).pow(getAchievementsCompleted()));
                }
                if (inChallenge('inf', 31)) eff = eff.mul(1.2);
                if (hasChallenge('inf', 23)) eff = eff.mul(2);
                effStr = `<div>每秒产出：${format(eff)} ${genIndex === 1 ? 'GP' : 'g' + (genIndex-1)}</div>`;
            }

            return `<div>等级：${formatWhole(lvl)}</div>
                <div>拥有数量：${formatWhole(amount)}</div>
                ${effStr}
                <div>价格：${format(price)} 无限点数</div>`;
        },
        canAfford() {
            ensureInfinityData();
            let lvl = player.inf.generators[pid] || new Decimal(0);
            let price = getInfBuyablePrice(pid, lvl);
            return player.inf.points && player.inf.points.gte(price);
        },
        buy() {
            ensureInfinityData();
            let lvl = player.inf.generators[pid] || new Decimal(0);
            let price = getInfBuyablePrice(pid, lvl);
            if (!player.inf.points || !player.inf.points.gte(price)) return;
            player.inf.points = player.inf.points.sub(price);
            player.inf.generators[pid] = lvl.add(1);
            if (!player.inf.gens[pid]) player.inf.gens[pid] = new Decimal(0);
            player.inf.gens[pid] = player.inf.gens[pid].add(1);
        },
    };
}

// ===== 星星系统 buyables =====
_infBuyables[31] = {
    title: "购买星星",
    cost(x) { return getStarPrice(player.inf.stars || new Decimal(0)); },
    display() {
        ensureInfinityData();
        let stars = player.inf.stars || new Decimal(0);
        let price = getStarPrice(stars);
        return `<div>当前星星数：${formatWhole(stars)}</div>
            <div>下一颗价格：${format(price)} 无限点数</div>`;
    },
    canAfford() {
        ensureInfinityData();
        let price = getStarPrice(player.inf.stars || new Decimal(0));
        return player.inf.points && player.inf.points.gte(price);
    },
    buy() {
        ensureInfinityData();
        let stars = player.inf.stars || new Decimal(0);
        let price = getStarPrice(stars);
        if (!player.inf.points || !player.inf.points.gte(price)) return;
        player.inf.points = player.inf.points.sub(price);
        player.inf.stars = stars.add(1);
    },
};

_infBuyables[32] = {
    title: "星星基础",
    cost(x) { return new Decimal(10).pow(new Decimal(36).add(new Decimal(12).mul(x))); },
    display() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(32);
        let price = new Decimal(10).pow(new Decimal(36).add(new Decimal(12).mul(lvl)));
        return `<div>等级：${formatWhole(lvl)}</div>
            <div>星星基础：${format(getStarBase())}</div>
            <div>价格：${format(price)} 无限点数</div>`;
    },
    canAfford() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(32);
        let price = new Decimal(10).pow(new Decimal(36).add(new Decimal(12).mul(lvl)));
        return player.inf.points && player.inf.points.gte(price);
    },
    buy() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(32);
        let price = new Decimal(10).pow(new Decimal(36).add(new Decimal(12).mul(lvl)));
        if (!player.inf.points || !player.inf.points.gte(price)) return;
        player.inf.points = player.inf.points.sub(price);
        player.inf.buyables[32] = lvl.add(1);
    },
};

_infBuyables[33] = {
    title: "星星指数",
    cost(x) { return new Decimal(10).pow(new Decimal(39).add(new Decimal(21).mul(x))); },
    display() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(33);
        let price = new Decimal(10).pow(new Decimal(39).add(new Decimal(21).mul(lvl)));
        return `<div>等级：${formatWhole(lvl)}</div>
            <div>星星指数：${format(getStarExponent())}</div>
            <div>价格：${format(price)} 无限点数</div>`;
    },
    canAfford() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(33);
        let price = new Decimal(10).pow(new Decimal(39).add(new Decimal(21).mul(lvl)));
        return player.inf.points && player.inf.points.gte(price);
    },
    buy() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(33);
        let price = new Decimal(10).pow(new Decimal(39).add(new Decimal(21).mul(lvl)));
        if (!player.inf.points || !player.inf.points.gte(price)) return;
        player.inf.points = player.inf.points.sub(price);
        player.inf.buyables[33] = lvl.add(1);
    },
};

_infBuyables[41] = {
    title: "无限升级扩展",
    cost(x) { return new Decimal(10).pow(new Decimal(6).add(new Decimal(6).mul(x))); },
    display() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(41);
        let price = new Decimal(10).pow(new Decimal(6).add(new Decimal(6).mul(lvl)));
        let maxStr = lvl.gte(9) ? '<div style="color:#f1c40f;">已达到上限</div>' : '';
        return `<div>等级：${formatWhole(lvl)} / 9</div>
            <div>u11 作用至 g${formatWhole(lvl.add(1))}</div>
            <div>价格：${format(price)} 星尘</div>
            ${maxStr}`;
    },
    canAfford() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(41);
        if (lvl.gte(9)) return false;
        let price = new Decimal(10).pow(new Decimal(6).add(new Decimal(6).mul(lvl)));
        return player.inf.stardust && player.inf.stardust.gte(price);
    },
    buy() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(41);
        if (lvl.gte(9)) return;
        let price = new Decimal(10).pow(new Decimal(6).add(new Decimal(6).mul(lvl)));
        if (!player.inf.stardust || !player.inf.stardust.gte(price)) return;
        player.inf.stardust = player.inf.stardust.sub(price);
        player.inf.buyables[41] = lvl.add(1);
    },
};

_infBuyables[42] = {
    title: "无限加成",
    cost(x) { return new Decimal(10).pow(new Decimal(9).add(new Decimal(3).mul(x))); },
    display() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(42);
        let price = new Decimal(10).pow(new Decimal(9).add(new Decimal(3).mul(lvl)));
        return `<div>等级：${formatWhole(lvl)}</div>
            <div>无限获取加成：×${format(lvl.add(1))}</div>
            <div>价格：${format(price)} 星尘</div>`;
    },
    canAfford() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(42);
        let price = new Decimal(10).pow(new Decimal(9).add(new Decimal(3).mul(lvl)));
        return player.inf.stardust && player.inf.stardust.gte(price);
    },
    buy() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(42);
        let price = new Decimal(10).pow(new Decimal(9).add(new Decimal(3).mul(lvl)));
        if (!player.inf.stardust || !player.inf.stardust.gte(price)) return;
        player.inf.stardust = player.inf.stardust.sub(price);
        player.inf.buyables[42] = lvl.add(1);
    },
};

_infBuyables[51] = {
    title: "指数盒提升",
    cost(x) { return new Decimal(10).pow(new Decimal(12).add(new Decimal(6).mul(x))); },
    display() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(51);
        let price = new Decimal(10).pow(new Decimal(12).add(new Decimal(6).mul(lvl)));
        let maxStr = lvl.gte(49) ? '<div style="color:#f1c40f;">已达到上限</div>' : '';
        return `<div>等级：${formatWhole(lvl)} / 49</div>
            <div>u12 效果 +${format(new Decimal(0.01).mul(lvl))}</div>
            <div>价格：${format(price)} 星尘</div>
            ${maxStr}`;
    },
    canAfford() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(51);
        if (lvl.gte(49)) return false;
        let price = new Decimal(10).pow(new Decimal(12).add(new Decimal(6).mul(lvl)));
        return player.inf.stardust && player.inf.stardust.gte(price);
    },
    buy() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(51);
        if (lvl.gte(49)) return;
        let price = new Decimal(10).pow(new Decimal(12).add(new Decimal(6).mul(lvl)));
        if (!player.inf.stardust || !player.inf.stardust.gte(price)) return;
        player.inf.stardust = player.inf.stardust.sub(price);
        player.inf.buyables[51] = lvl.add(1);
    },
};

_infBuyables[52] = {
    title: "被动加速",
    cost(x) { return new Decimal(10).pow(new Decimal(18).add(new Decimal(6).mul(x))); },
    display() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(52);
        let price = new Decimal(10).pow(new Decimal(18).add(new Decimal(6).mul(lvl)));
        let maxStr = lvl.gte(99) ? '<div style="color:#f1c40f;">已达到上限</div>' : '';
        return `<div>等级：${formatWhole(lvl)} / 99</div>
            <div>u65 效果 +${format(new Decimal(0.01).mul(lvl))}</div>
            <div>价格：${format(price)} 星尘</div>
            ${maxStr}`;
    },
    canAfford() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(52);
        if (lvl.gte(99)) return false;
        let price = new Decimal(10).pow(new Decimal(18).add(new Decimal(6).mul(lvl)));
        return player.inf.stardust && player.inf.stardust.gte(price);
    },
    buy() {
        ensureInfinityData();
        let lvl = getStardustBuyableLvl(52);
        if (lvl.gte(99)) return;
        let price = new Decimal(10).pow(new Decimal(18).add(new Decimal(6).mul(lvl)));
        if (!player.inf.stardust || !player.inf.stardust.gte(price)) return;
        player.inf.stardust = player.inf.stardust.sub(price);
        player.inf.buyables[52] = lvl.add(1);
    },
};

addLayer("inf", {
    name: "无限",
    symbol: "无限",
    position: 0,
    row: 3,
    color: "#ff66dd",
    type: "none",
    resource: "无限点数",
    startData() { return { 
        unlocked: true, points: new Decimal(0), infinity: new Decimal(0),
        gp: new Decimal(0), ge: new Decimal(0.666), stars: new Decimal(0), stardust: new Decimal(0),
        upgrades: [],
        challenge_broken: false,
        lastActiveChallenge: null,
        lastIPGain: new Decimal(0),
        buyables: {},
        generators: { 11: new Decimal(0), 12: new Decimal(0), 13: new Decimal(0), 14: new Decimal(0), 15: new Decimal(0), 21: new Decimal(0), 22: new Decimal(0), 23: new Decimal(0), 24: new Decimal(0), 25: new Decimal(0) },
        gens: { 11: new Decimal(0), 12: new Decimal(0), 13: new Decimal(0), 14: new Decimal(0), 15: new Decimal(0), 21: new Decimal(0), 22: new Decimal(0), 23: new Decimal(0), 24: new Decimal(0), 25: new Decimal(0) }
    }},
    layerShown(){ return hasAchievement('ach', 47); },
    update(diff) {
        ensureInfinityData();
        // 归一化 null / undefined，避免误触发重置
        let curChallenge = player.inf.activeChallenge || null;
        let lastChallenge = player.inf.lastActiveChallenge || null;
        if (lastChallenge !== curChallenge) {
            player.inf.lastActiveChallenge = curChallenge;
            hardResetAll();
        }
        let currentGens = {};
        for (let bid of genIds) currentGens[bid] = player.inf.gens[bid] || new Decimal(0);

        // 星尘产出
        let sdGain = getStardustGain().mul(diff);
        if (sdGain.gt(0)) player.inf.stardust = player.inf.stardust.add(sdGain);

        // 成就 #51（id 82）：每个已完成的成就 ×1.02 加成所有生成器效果（每 tick 只算一次）
        let ach82Mult = new Decimal(1);
        if (typeof hasAchievement === 'function' && hasAchievement('ach', 82)) {
            ach82Mult = new Decimal(1.02).pow(getAchievementsCompleted());
        }

        for (let i = 0; i < 10; i++) {
            let bid = genIds[i];
            let lvl = player.inf.generators[bid] || new Decimal(0);
            if (lvl.lte(0)) continue;
            let eff = currentGens[bid].mul(new Decimal(2).pow(lvl.sub(1)));
            if (i === 0) {
                if (hasAchievement('ach', 51)) eff = eff.mul(1.2);
                if (hasAchievement('ach', 57)) eff = eff.mul(1.2);
                if (player.inf.upgrades.includes(23)) eff = eff.mul(5);
                if (player.inf.upgrades.includes(24)) eff = eff.mul(player.inf.gp.add(10).log10());
                if (player.inf.upgrades.includes(32)) eff = eff.mul(new Decimal(1.5).mul(player.inf.points.add(10).log10()));
                if (player.inf.upgrades.includes(42)) {
                    let challCount = getChallengesCompleted();
                    eff = eff.mul(Decimal.pow(32, 0.1 + challCount / 10));
                }
                if (player.inf.upgrades.includes(54)) eff = eff.mul(10);
                if (player.inf.upgrades.includes(63)) {
                    let g3Count = player.inf.generators[13] || new Decimal(0);
                    let u63Eff;
                    if (g3Count.lte(0)) u63Eff = new Decimal(1);
                    else if (g3Count.lte("1e10")) u63Eff = g3Count.pow(2).max(1);
                    else u63Eff = new Decimal("1e20").mul(g3Count.sub("1e10"));
                    eff = eff.mul(u63Eff);
                }
            } else if (i === 1) {
                if (player.inf.upgrades.includes(25)) eff = eff.mul(3);
                if (player.inf.upgrades.includes(33)) eff = eff.mul(new Decimal(1.2).mul(player.inf.points.add(10).log10()));
                if (player.inf.upgrades.includes(34)) eff = eff.mul(new Decimal(1).add(player.inf.infinity.pow(0.5)));
                if (player.inf.upgrades.includes(42)) {
                    let challCount = getChallengesCompleted();
                    eff = eff.mul(Decimal.pow(22.5, 0.1 + challCount / 10));
                }
            } else if (i === 2) {
                if (player.inf.upgrades.includes(51)) {
                    let inf = player.inf.infinity || new Decimal(0);
                    eff = eff.mul(new Decimal(1.05).mul(inf.add(1).log10()));
                }
                if (player.inf.upgrades.includes(62)) {
                    let g2Count = player.inf.generators[12] || new Decimal(0);
                    eff = eff.mul(g2Count.max(1));
                }
            } else if (i === 3) {
                // u81：已购买的 g3 加成 g4，公式 1.1 * (g3 + 1)
                if (player.inf.upgrades.includes(81)) {
                    let g3Count = player.inf.generators[13] || new Decimal(0);
                    eff = eff.mul(new Decimal(1.1).mul(g3Count.add(1)));
                }
            }
            // u11 扩展：根据星尘购买项 41 的等级，生效至 g(1+等级)
            if (player.inf.upgrades.includes(11) && new Decimal(i).lte(getStardustBuyableLvl(41))) {
                eff = eff.mul(player.inf.infinity.max(1));
            }
            if (typeof hasAchievement === 'function' && hasAchievement('ach', 76)) eff = eff.mul(2);
            if (ach82Mult.gt(1)) eff = eff.mul(ach82Mult);
            if (inChallenge('inf', 31)) eff = eff.mul(1.2);
            if (hasChallenge('inf', 23)) eff = eff.mul(2);
            let gain = eff.mul(diff);
            if (gain.lte(0)) continue;
            if (i === 0) {
                let sdEff = getStardustEffect();
                gain = gain.mul(sdEff);
                player.inf.gp = (player.inf.gp || new Decimal(0)).add(gain);
            } else {
                let prevBid = genIds[i-1];
                player.inf.gens[prevBid] = (player.inf.gens[prevBid] || new Decimal(0)).add(gain);
            }
        }

        // u65：每秒自动获取重置时可获取的无限的 (1% + lvl52%)
        if (player.inf.upgrades.includes(65)) {
            let lvl52 = getStardustBuyableLvl(52);
            let rate = new Decimal(0.01).add(new Decimal(0.01).mul(lvl52));
            let passive = getInfinityGain().mul(rate).mul(diff);
            if (passive.gt(0)) player.inf.infinity = player.inf.infinity.add(passive);
        }
    },
    upgrades: {
        rows: 9,
        cols: 5,
        11: {
            title: "无限生成与自动化",
            description: "无限次数加成g1效率和分数获取<br>可以自动最大购买十种颜色乘数工厂",
            cost: new Decimal(1),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => true,
            effect() {
                let inf = player.inf.infinity || new Decimal(1);
                return inf.max(1);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        12: {
            title: "指数盒",
            description: "通用指数+0.01",
            cost: new Decimal(1),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 11),
            effect() { return new Decimal(0.01); },
            effectDisplay() { return hasUpgrade('inf', 12) ? "+0.01" : "+0.00"; }
        },
        13: {
            title: "快速生产",
            description: "所有颜色乘数工厂效率*1.1",
            cost: new Decimal(1),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 12),
            effect() { return new Decimal(1.1); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        14: {
            title: "更快生产",
            description: "所有颜色乘数工厂效率*1.2",
            cost: new Decimal(2),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 13),
            effect() { return new Decimal(1.2); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        15: {
            title: "声望声望",
            description: "pm获取基础+0.14",
            cost: new Decimal(3),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 14),
            effect() { return new Decimal(2.70); },
            effectDisplay() { return hasUpgrade('inf', 15) ? "+0.14" : "+0.00"; }
        },
        21: {
            title: "自动转生",
            description: "解锁自动转生",
            cost: new Decimal(3),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 15),
        },
        22: {
            title: "挑战！",
            description: "解锁无限挑战",
            cost: new Decimal(5),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 21),
        },
        23: {
            title: "生成器与常数",
            description: "g1效率*5",
            cost: new Decimal(16),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 22),
            effect() { return new Decimal(5); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        24: {
            title: "生成器与能量",
            description: "g1效率随着当前gp提升",
            cost: new Decimal(32),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 23),
            effect() { return player.inf.gp.add(10).log10(); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        25: {
            title: "生产器与常数II",
            description: "g2效率*3",
            cost: new Decimal(128),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 24),
            effect() { return new Decimal(3); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        31: {
            title: "自动运转",
            description: "解锁自动晋升",
            cost: new Decimal(256),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 25),
        },
        32: {
            title: "弱生成器",
            description: "IP加成g1",
            cost: new Decimal(300),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 31),
            effect() { return new Decimal(1.5).mul(player.inf.points.add(10).log10()); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        33: {
            title: "中等生成器",
            description: "IP加成g2",
            cost: new Decimal(400),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 32),
            effect() { return new Decimal(1.2).mul(player.inf.points.add(10).log10()); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        34: {
            title: "第一，但更强",
            description: "无限加成g2",
            cost: new Decimal(512),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 33),
            effect() { return new Decimal(1).add(player.inf.infinity.pow(0.5)); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        35: {
            title: "效率V",
            description: "生成器指数（ge）+0.08",
            cost: new Decimal(1024),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 34),
            effect() { return new Decimal(0.08); },
            effectDisplay() { return `+${format(this.effect())}`; }
        },
        41: {
            title: "挑战加成无限点",
            description: "已完成挑战数加成ip获取",
            cost: new Decimal(2048),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 35),
            effect() {
                let challCount = getChallengesCompleted();
                return Decimal.pow(3, 0.1 + challCount / 10);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        42: {
            title: "挑战加成生成器",
            description: "已完成挑战数加成g1、g2",
            cost: new Decimal(2048),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 41),
            effect() {
                let challCount = getChallengesCompleted();
                return Decimal.pow(32, 0.1 + challCount / 10);
            },
            effectDisplay() { return `g1: ×${format(this.effect())}`; }
        },
        43: {
            title: "无限到IP",
            description: "无限加成IP获取",
            cost: new Decimal(5000),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 42),
            effect() { return new Decimal(1).add(player.inf.infinity.pow(0.1)); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        44: {
            title: "强化晋升",
            description: "已完成挑战数加成晋升4效果",
            cost: new Decimal(5120),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 43),
            effect() {
                let challCount = getChallengesCompleted();
                return Decimal.pow(5, 0.1 + challCount / 10);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        45: {
            title: "挑战到晋升经验",
            description: "基于已完成挑战数加成晋升经验获取（指数形式）",
            cost: new Decimal(12345),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 44),
            effect() {
                let challCount = getChallengesCompleted();
                return Decimal.pow(1.5, 0.1 + challCount / 10);
            },
            effectDisplay() { return `^${format(this.effect())}`; }
        },
        51: {
            title: "轮到第三个了",
            description: "无限次数加成 g3 效率",
            cost: new Decimal(10000),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 44),
            effect() {
                let inf = (player.inf && player.inf.infinity) || new Decimal(0);
                return new Decimal(1.05).mul(inf.add(1).log10());
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        52: {
            title: "我需要更多IP",
            description: "IP 获取随分数提升",
            cost: new Decimal(12221),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 51),
            effect() {
                let p = (player.points || new Decimal(1));
                if (p.lt(1)) p = new Decimal(1);
                return p.log10().add(10).pow(0.2221);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        53: {
            title: "无限bonus！",
            description: "无限获取基于分数提升",
            cost: new Decimal(114514),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 52),
            effect() {
                let p = (player.points || new Decimal(1));
                if (p.lt(10)) return new Decimal(1);
                let lgs = p.log10();
                if (lgs.lt(10)) return new Decimal(1);
                return lgs.log10().pow(0.67);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        54: {
            title: "生成器与常数III",
            description: "g1 效果 ×10",
            cost: new Decimal(229028),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 53),
            effect() { return new Decimal(10); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        55: {
            title: "经验爆炸",
            description: "晋升经验获取 ^1.2",
            cost: new Decimal(685000),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 54),
            effect() { return new Decimal(1.2); },
            effectDisplay() { return `^${format(this.effect())}`; }
        },
        61: {
            title: "晋升大增",
            description: "晋升3效果基础 +0.2",
            cost: new Decimal(750000),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 55),
            effect() { return new Decimal(0.2); },
            effectDisplay() { return `+${format(this.effect())}`; }
        },
        62: {
            title: "二带三",
            description: "已购买的 g2 加成 g3",
            cost: new Decimal(888888),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 61),
            effect() {
                let g2Count = (player.inf && player.inf.generators && player.inf.generators[12]) || new Decimal(0);
                return g2Count.max(1);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        63: {
            title: "三带一",
            description: "已购买的 g3 加成 g1",
            cost: new Decimal(999999),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 62),
            effect() {
                let g3Count = (player.inf && player.inf.generators && player.inf.generators[13]) || new Decimal(0);
                if (g3Count.lte(0)) return new Decimal(1);
                if (g3Count.lte("1e10")) return g3Count.pow(2).max(1);
                return new Decimal("1e20").mul(g3Count.sub("1e10"));
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        64: {
            title: "盒中盒",
            description: "通用指数整体 ×1.1",
            cost: new Decimal(1.2e6),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 63),
            effect() { return new Decimal(1.1); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        65: {
            title: "被动无限",
            description: "每秒自动获取重置时可获取的无限的 1%（不重置任何东西）",
            cost: new Decimal(3e6),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 64),
        },
        71: {
            title: "pm的崛起",
            description: "无限加成 pm 软上限后的指数",
            cost: new Decimal(3333333),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 65),
            effect() {
                let inf = (player.inf && player.inf.infinity) || new Decimal(0);
                return inf.add(10).log10();
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        72: {
            title: "pe二次增益",
            description: "pe 再次提升 pm 获取",
            cost: new Decimal(4567890),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 71),
            effect() {
                ensurePrestigeData();
                let pe = new Decimal(player.pt.pe);
                if (pe.lt(1.5)) return new Decimal(1);
                if (pe.lt(3)) return pe.div(1.5);
                return new Decimal(2).mul(pe.sub(2).pow(0.3));
            },
            effectDisplay() { return `^${format(this.effect())}`; }
        },
        73: {
            title: "指数盒^3",
            description: "通用指数整体再次 ×1.1",
            cost: new Decimal(5555555),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 72),
            effect() { return new Decimal(1.1); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        74: {
            title: "经验也要膨胀",
            description: "分数超过 e3080 后以指数形式加成晋升经验获取",
            cost: new Decimal(6666666),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 73),
            effect() {
                if (!player.points || player.points.lte("1e3080")) return new Decimal(1);
                let lgs = player.points.log10();
                if (lgs.lte(6160)) {
                    return lgs.div(3080);
                }
                return new Decimal(2).add(lgs.div(6160).sub(1).pow(0.2221));
            },
            effectDisplay() { return `^${format(this.effect())}`; }
        },
        75: {
            title: "经验膨胀分数",
            description: "晋升经验加成分数获取",
            cost: new Decimal(8888888),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 74),
            effect() {
                let xp = (player.prm && player.prm.points) || new Decimal(0);
                if (xp.lte(1)) return new Decimal(1);
                let xpExp;
                if (xp.lte("1.8e308")) {
                    xpExp = new Decimal(0.7);
                } else {
                    let prm4 = getPrm4Effect();
                    xpExp = new Decimal(0.7).add(new Decimal(0.1).mul(prm4.add(1).log10()));
                    if (xpExp.gt(5)) xpExp = new Decimal(5);
                }
                return xp.pow(xpExp);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        81: {
            title: "三带四",
            description: "已购买的 g3 加成 g4",
            cost: new Decimal(1e11),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 75),
            effect() {
                let g3Count = (player.inf && player.inf.generators && player.inf.generators[13]) || new Decimal(0);
                return new Decimal(1.1).mul(g3Count.add(1));
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        82: {
            title: "差一点就到1",
            description: "生成器指数 +0.15",
            cost: new Decimal(1e12),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 81),
            effect() { return new Decimal(0.15); },
            effectDisplay() { return `+${format(this.effect())}`; }
        },
        83: {
            title: "挑战效率",
            description: "所有颜色工厂效率 ×4",
            cost: new Decimal(2e12),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 82),
            effect() { return new Decimal(4); },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        84: {
            title: "通胀时代",
            description: "生成器倍率加成晋升3基础",
            cost: new Decimal(2e13),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 83),
            effect() {
                let gp = (player.inf && player.inf.gp) || new Decimal(0);
                let ge = getEffectiveGE();
                let gpMult = getGPMult(gp, ge);
                let u84mult = new Decimal(1);
                if (gpMult.gt(0)) {
                    u84mult = gpMult.log10().add(1).log10().add(1).pow(1/3);
                }
                return u84mult.max(1);
            },
            effectDisplay() { return `×${format(this.effect())}`; }
        },
        85: {
            title: "动态指数",
            description: "gp 加成生成器指数",
            cost: new Decimal("1e30"),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 84),
            effect() {
    let gp = (player.inf && player.inf.gp) || new Decimal(0);
    let gpSafe = gp.max(1);
    let bonus = gpSafe.log10().add(1).log10().add(1).div(50).mul(1.8);
    if (bonus.gt(16.38)) bonus = new Decimal(16.38);
    return bonus;
},
            effectDisplay() { return `+${format(this.effect())}`; }
        },
        91: {
            title: "陨星",
            description: "解锁星星",
            cost: new Decimal("1e33"),
            currencyLayer: "inf", currencyInternalName: "points", currencyDisplayName: "无限点数",
            unlocked: () => hasUpgrade('inf', 85),
        },
    },
    challenges: {
        rows: 3,
        cols: 3,
        11: { name: "离子化速度", challengeDescription: "晋升2和4被禁用", rewardDescription: "晋升2指数+0.1，晋升4指数+0.075", goal: new Decimal("1.8e308"), unlocked: () => true },
        12: { name: "下降", challengeDescription: "颜色乘数获取最终速度^0.69", rewardDescription: "颜色乘数获取*2", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 11) },
        13: { name: "第一根源", challengeDescription: "通用指数-0.4", rewardDescription: "通用指数+0.03", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 12) },
        21: { name: "陡峭攀升", challengeDescription: "转生和晋升收益^0.4（包括pm、prm1～4effect）", rewardDescription: "所有晋升获得免费等级+3", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 13) },
        22: { name: "被解雇", challengeDescription: "所有晋升收益大幅削弱", rewardDescription: "所有晋升收益小幅提升", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 21) },
        23: { name: "枯竭", challengeDescription: "点数获取每秒/5", rewardDescription: "所有生成器效果*2", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 22) },
        31: { name: "二次划分", challengeDescription: "所有倍率/2（仅包括颜色乘数基础效率、pe、pm、晋升经验获取、前三个晋升效果）", rewardDescription: "所有倍率*1.2", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 23) },
        32: { name: "反升", challengeDescription: "晋升被禁用（无法购买、获取经验）", rewardDescription: "晋升价格基础-0.13", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 31) },
        33: { name: "孤立主义", challengeDescription: "你只能购买前四种颜色乘数", rewardDescription: "无限获取*2、所有颜色价格倍率^0.9", goal: new Decimal("1.8e308"), unlocked: () => hasChallenge('inf', 32) },
    },
    doReset(resettingLayer) { hardResetAll(); },
    clickables: {
        11: {
            title() { return "进行无限重置"; },
            display() {
                let can = player.points && player.points.gte("1.7976e308");
                let ipGain = getInfinityIP(player.points);
                return `<div style="font-size:18px;margin:10px 0;">重置以获得 <span style="color:#ff66dd;font-weight:bold;">${format(ipGain)}</span> 无限点数</div>`;
            },
            canClick() { return player.points && player.points.gte("1.7976e308"); },
            onClick() { doInfinityReset(); },
            style() {
                let can = player.points && player.points.gte("1.7976e308");
                return {
                    "width": "320px", "height": "140px", "min-height": "140px", "border-radius": "10px",
                    "border": "2px solid " + (can ? "#ff66dd" : "#555555"),
                    "background-color": can ? "#3b1b3b" : "#2a2a2a", "color": "#ffffff",
                    "cursor": can ? "pointer" : "not-allowed", "opacity": can ? "1" : "0.7",
                    "padding": "8px", "text-align": "center", "transition": "background-color 0.15s, border-color 0.15s",
                };
            },
        },
        12: {
            title() { return "打破无限"; },
            display() {
                let on = player.inf.challenge_broken;
                return `打破无限<br>${on ? "<span style='color:#7fff7f;'>已开启</span>" : "<span style='color:#ff7f7f;'>已关闭</span>"}<br>开启后分数突破 1.8e308 上限`;
            },
            unlocked() { 
                let challConfig = layers.inf.challenges;
                let ids = Object.keys(challConfig).filter(k => !isNaN(k));
                return ids.length > 0 && ids.every(id => hasChallenge('inf', parseInt(id)));
            },
            canClick() { return true; },
            onClick() { player.inf.challenge_broken = !player.inf.challenge_broken; },
            style() { 
                let on = player.inf.challenge_broken;
                return { 
                    "width": "300px", "height": "80px", "font-size": "16px", "color": "#ffffff", 
                    "background-color": on ? "#1b3a1b" : "#333", 
                    "border": "2px solid #ffd700", "border-radius": "8px", "cursor": "pointer" 
                }; 
            }
        }
    },
    microtabs: {
        main: {
            "升级": { content: ["upgrades"] },
            "生成器": {
                content: [
                    ["display-text", function() {
                        ensureInfinityData();
                        let ge = getEffectiveGE();
                        let gp = player.inf.gp || new Decimal(0);
                        let gpMult = getGPMult(gp, ge);
                        return `<div style="font-size:20px;color:#fefefe;margin-bottom:15px;">
                                    你拥有 <span style="color:#00ff00;">${format(gp)}</span><sup><span style="color:#00ffff;">${format(ge)}</span></sup> 生成器能量<br>
                                    加成各种颜色乘数获取 * <span style="color:#87ceeb;">${format(gpMult)}</span>
                                </div>`;
                    }],
                    ["row", [["buyable", 11], ["buyable", 12], ["buyable", 13], ["buyable", 14], ["buyable", 15]]],
                    ["row", [["buyable", 21], ["buyable", 22], ["buyable", 23], ["buyable", 24], ["buyable", 25]]]
                ]
            },
            "挑战": {
                content: ["challenges", ["display-text", "<br><br>"], ["row", [["clickable", 12]]]],
                unlocked: () => hasUpgrade('inf', 22)
            },
            "星星": {
                content: [
                    ["display-text", function() {
                        ensureInfinityData();
                        let stars = player.inf.stars || new Decimal(0);
                        let stardust = player.inf.stardust || new Decimal(0);
                        let sdGain = getStardustGain();
                        let sdEff = getStardustEffect();
                        let base = getStarBase();
                        let exp = getStarExponent();
                        return `<div style="font-size:20px;color:#fefefe;margin-bottom:15px;">
                            你拥有 <span style="color:#ffd700;">${formatWhole(stars)}</span> 颗星星<br>
                            星尘：<span style="color:#87ceeb;">${format(stardust)}</span><br>
                            每秒产生星尘：${format(sdGain)}<br>
                            星尘效果（加成 gp 获取）：×${format(sdEff)}<br>
                            星星基础：${format(base)}　星星指数：${format(exp)}
                        </div>`;
                    }],
                    ["row", [["buyable", 31]]],
                    ["display-text", "<div style='color:#fefefe; font-size:18px; margin:10px 0;'>星星购买项（花费 IP）</div>"],
                    ["row", [["buyable", 32], ["buyable", 33]]],
                    ["display-text", "<div style='color:#fefefe; font-size:18px; margin:10px 0;'>星尘购买项（花费星尘）</div>"],
                    ["row", [["buyable", 41], ["buyable", 42]]],
                    ["row", [["buyable", 51], ["buyable", 52]]]
                ],
                unlocked: () => hasUpgrade('inf', 91)
            }
        }
    },
    buyables: _infBuyables,
    tabFormat: [
        ["display-text", function() { return getPointsDisplay() }],
        "main-display",
        ["display-text", function() {
            ensureInfinityData();
            return `<div style="font-size:20px;color:#fefefe;margin-bottom:10px;margin-top:5px;">你有 ${format(player.inf.infinity)} 无限</div>`;
        }],
        ["clickable", 11],
        ["microtabs", "main"]
    ]
})