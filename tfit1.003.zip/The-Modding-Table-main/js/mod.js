let modInfo = {
	name: "乘数增量页",
	nameI18N: "TFITa",
	id: "Silite308_01",
	author: "Silite308",
	pointsName: "点数",
	modFiles: ["layers.js", "tree.js"],

	internationalizationMod: false,
	changedDefaultLanguage: true,

	initialStartPoints: new Decimal (0),
	offlineLimit: 0,
}

// ===== 分数硬上限 =====
var MAX_POINTS = new Decimal("1.8e308");

var colors = {
	button: { width: '250px', height: '40px', font: '25px', border: '3px' },
	default: {
		1: "#ffffff", 2: "#bfbfbf", 3: "#7f7f7f",
		color: "#dfdfdf", points: "#ffffff", locked: "#bf8f8f",
		background: "#0f0f0f", background_tooltip: "rgba(0, 0, 0, 0.75)",
	},
}

function hiddenLeftTable(){ return false }

let VERSION = { num: "1.003", name: "Literally nothing" }

function changelog(){
	return i18n(`
		<br><br><br><h1>更新日志:</h1><br>(存在<span style='color: red'>剧透警告</span>)<br><br>
		<span style="font-size: 22px;">
		<h3>v1.003 直到永恒之前 26/11/08</h3><br>
		- 更新无限升级（全部）<br>
		- 更新星星<br>
		- 新增一个加速里程碑<br>
		- 残局：60成就（达到永恒）<br><br>
			<h3>v1.002 无限升级 26/11/05</h3><br>
			- 更新了无限升级<br>
			- 更新无限挑战、生成器<br>
			- 更新自动化层级<br>
			- 层级层新增加速里程碑，你可以加快游戏进程<br>
			- 新增打破无限<br>
			- 优化了界面显示和部分文本<br>
			- 中途修复了无数bug<br>
			- 残局：46成就<br><br>
			<h3>v1.001.1 无限 26/10/31</h3><br>
			- 更新至无限前<br>
			- 残局：28成就（达到无限）<br>
			- 修复了一个小bug（patch 1）<br><br>
			<h3>v1.000 基础更新 26/10/18</h3><br>
				- 开发了本游戏<br>
				- 本游戏大部分内容<s>照抄</s>基于旋转放置玩法开发<br>
				- 残局：10成就
			<br><br>
		`, false)
} 

function winText(){
	return i18n(`你暂时完成了游戏!`, `Congratulations! You have reached the end and beaten this game, but for now...`, false)
}

var doNotCallTheseFunctionsEveryTick = ["blowUpEverything"]

function getStartPoints(){ return new Decimal(modInfo.initialStartPoints) }
function canGenPoints(){ return true }

function getChallengesCompleted() {
    let count = 0;
    if (player.inf && player.inf.challenges) {
        for (let cid in player.inf.challenges) {
            if (player.inf.challenges[cid]) count++;
        }
    }
    return count;
}

// 获取已完成成就数量（动态统计，用于成就 #51）
function getAchievementsCompleted() {
    if (typeof layers === 'undefined' || !layers.ach || !layers.ach.achievements) return 0;
    let achIds = Object.keys(layers.ach.achievements).filter(k => !isNaN(k));
    return achIds.filter(id => hasAchievement('ach', parseInt(id))).length;
}

// ===== 星星系统 =====

function getStardustBuyableLvl(id) {
    if (!player.inf || !player.inf.buyables) return new Decimal(0);
    return new Decimal(player.inf.buyables[id] || 0);
}

function getStarBase() {
    return new Decimal(2.75).add(new Decimal(0.275).mul(getStardustBuyableLvl(32)));
}

function getStarExponent() {
    return new Decimal(0.4).add(new Decimal(0.05).mul(getStardustBuyableLvl(33)));
}

function getStardustGain() {
    if (!player.inf) return new Decimal(0);
    let stars = player.inf.stars || new Decimal(0);
    let base = getStarBase();
    return new Decimal(0.25).mul(base.pow(stars));
}

function getStardustEffect() {
    if (!player.inf) return new Decimal(1);
    let sd = player.inf.stardust || new Decimal(0);
    if (sd.lte(0)) return new Decimal(1);
    let exp = getStarExponent();
    let eff = sd.pow(exp);
    if (eff.lt(1)) eff = new Decimal(1);
    return eff;
}

// n 为已拥有的星星数，返回购买下一颗的价格
function getStarPrice(n) {
    let nDec = new Decimal(n);
    let starIndex = nDec.add(1);
    if (starIndex.lte(19)) {
        return new Decimal(10).pow(new Decimal(33).add(new Decimal(3).mul(starIndex.sub(1))));
    } else if (starIndex.lte(32)) {
        return new Decimal(10).pow(new Decimal(87).add(new Decimal(7).mul(starIndex.sub(19))));
    } else if (starIndex.eq(33)) {
        return new Decimal("1e200");
    } else {
        return new Decimal("1e200").mul(new Decimal(10).pow(new Decimal(15).mul(starIndex.sub(33))));
    }
}

// ===== 乘数系统 =====

var multiplierOrder = ["red", "orange", "yellow", "green", "teal", "cyan", "blue", "purple", "pink", "white"]

var multiplierNames = {
    red: "红色乘数", orange: "橙色乘数", yellow: "黄色乘数", green: "绿色乘数", teal: "蓝绿色乘数",
    cyan: "青色乘数", blue: "蓝色乘数", purple: "紫色乘数", pink: "粉色乘数", white: "白色乘数",
}

var multiplierColors = {
    red:    "#ff5555", orange: "#ff9900", yellow: "#ffff00", green:  "#00ff00", teal:   "#00c896",
    cyan:   "#00ffff", blue:   "#6a6aff", purple: "#b45cff", pink:   "#ff69b4", white:  "#ffffff",
}

var prestigeMultColor = "#ffd700";
var generalExponentColor = "#00bfff";
var MULT_GROWTH_PER_LEVEL = new Decimal(0.001);

var buyableConfig = {
    red:    { id: 11, base: new Decimal(4),    mult: new Decimal(1.2),  eff: new Decimal(0.02)   },
    orange: { id: 12, base: new Decimal(100),  mult: new Decimal(1.24), eff: new Decimal(0.01)   },
    yellow: { id: 13, base: new Decimal(1000), mult: new Decimal(1.28), eff: new Decimal(0.0067) },
    green:  { id: 14, base: new Decimal(1e4),  mult: new Decimal(1.32), eff: new Decimal(0.005)  },
    teal:   { id: 15, base: new Decimal(1e6),  mult: new Decimal(1.36), eff: new Decimal(0.004)  },
    cyan:   { id: 21, base: new Decimal(1e9),  mult: new Decimal(1.4),  eff: new Decimal(0.0033) },
    blue:   { id: 22, base: new Decimal(1e12), mult: new Decimal(1.44), eff: new Decimal(0.0029) },
    purple: { id: 23, base: new Decimal(1e15), mult: new Decimal(1.48), eff: new Decimal(0.0025) },
    pink:   { id: 24, base: new Decimal(1e18), mult: new Decimal(1.52), eff: new Decimal(0.0022) },
    white:  { id: 25, base: new Decimal(1e27), mult: new Decimal(1.56), eff: new Decimal(0.002)  },
};

function getBuyablePrice(key, lvl){
    let cfg = buyableConfig[key];
    let x = new Decimal(lvl || 0);
    let baseMult = cfg.mult;
    if (key === "red" && typeof hasAchievement === 'function' && hasAchievement('ach', 37)) {
        baseMult = baseMult.sub(0.03);
    }
    if (typeof hasChallenge === 'function' && hasChallenge('inf', 33)) {
        baseMult = baseMult.pow(0.9);
    }
    let m = baseMult.add(MULT_GROWTH_PER_LEVEL.mul(x));
    return cfg.base.mul(m.pow(x));
}

function _getBuyLvl(id){
    if (!player.p) return new Decimal(0);
    if (!player.p.buyables) player.p.buyables = {};
    if (player.p.buyables[id] === undefined) player.p.buyables[id] = new Decimal(0);
    return new Decimal(player.p.buyables[id]);
}
function _setBuyLvl(id, v){
    if (!player.p) return;
    if (!player.p.buyables) player.p.buyables = {};
    player.p.buyables[id] = new Decimal(v);
}

function getGPMult(gp, ge) {
    let val = gp.pow(ge);
    if (val.lt(1)) return new Decimal(1);
    if (val.gt("1e1000")) {
        return new Decimal(10).pow(new Decimal(1000).mul(val.log10().log10()));
    }
    return val;
}

// 计算有效生成器指数（含 u35、u82、u85）
function getEffectiveGE() {
    ensureInfinityData();
    let gp = player.inf.gp || new Decimal(0);
    let ge = player.inf.ge || new Decimal(0.666);
    let upgs = player.inf.upgrades || [];
    if (upgs.includes(35)) ge = ge.add(0.08);
    if (upgs.includes(82)) ge = ge.add(0.15);
    if (upgs.includes(85)) {
    let gpSafe = gp.max(1);
    let bonus = gpSafe.log10().add(1).log10().add(1).div(50).mul(1.8);
    if (bonus.gt(16.38)) bonus = new Decimal(16.38);
    ge = ge.add(bonus);
}
    return ge;
}

function getMultiplierGain(key){
    let cfg = buyableConfig[key];
    let lvl = _getBuyLvl(cfg.id);
    let effectiveLvl = lvl;
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 71)) {
        effectiveLvl = effectiveLvl.add(12);
    }
    if (effectiveLvl.lte(0)) return new Decimal(0);
    
    ensureAscensionData();
    let prm1 = getPrm1Effect();
    let prm2 = getPrm2Effect();
    
    let ach10Mult = (typeof hasAchievement === 'function' && hasAchievement('ach', 23)) ? new Decimal(1.05) : new Decimal(1);
    let ach13Mult = (typeof hasAchievement === 'function' && hasAchievement('ach', 26)) ? new Decimal(1.05) : new Decimal(1);
    let ach15Mult = (typeof hasAchievement === 'function' && hasAchievement('ach', 31)) ? new Decimal(1.1) : new Decimal(1);

    let eff = cfg.eff;
    if (inChallenge('inf', 31)) eff = eff.div(2);
    if (hasChallenge('inf', 31)) eff = eff.mul(1.2);

    let gain = eff.mul(prm1).mul(effectiveLvl).mul(prm2).mul(ach10Mult).mul(ach13Mult).mul(ach15Mult);
    
    if ((key === "red" || key === "orange" || key === "yellow") && 
        typeof hasAchievement === 'function' && hasAchievement('ach', 44)) {
        if (gain.gt(0)) gain = gain.pow(1.03);
    }
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 45)) {
        if (gain.gt(0)) gain = gain.pow(1.01);
    }

    if (key === "red" && typeof hasAchievement === 'function' && hasAchievement('ach', 51)) {
        gain = gain.mul(1.2);
    }

    ensureInfinityData();
    let upgs = player.inf.upgrades || [];
    if (upgs.includes(13)) gain = gain.mul(1.1);
    if (upgs.includes(14)) gain = gain.mul(1.2);
    // u83：所有颜色工厂效率 ×4
    if (upgs.includes(83)) gain = gain.mul(4);

    let gp = player.inf.gp || new Decimal(0);
    let ge = getEffectiveGE();
    let gpMult = getGPMult(gp, ge);
    gain = gain.mul(gpMult);
    
    if (inChallenge('inf', 12)) gain = gain.pow(0.69);
    if (hasChallenge('inf', 12)) gain = gain.mul(2);

    // 成就 #48（id 76）：所有颜色乘数工厂 ×2
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 76)) {
        gain = gain.mul(2);
    }

    return gain;
}

function multiplierProduction(diff){
    if (!player.p) return;
    for (let k of multiplierOrder) {
        let gain = getMultiplierGain(k);
        if (gain.lte(0)) continue;
        let eff = gain.mul(diff);
        let cur = new Decimal(player.p[k] === undefined ? 1 : player.p[k]);
        if (cur.lt(1)) cur = new Decimal(1);
        player.p[k] = cur.add(eff);
    }
}

function ensureMultiplierData(){
    if(!player.p) return
    for (let k of multiplierOrder){
        if(player.p[k] === undefined) player.p[k] = new Decimal(1)
    }
    if (!player.p.buyables) player.p.buyables = {}
    for (let k of multiplierOrder){
        let id = buyableConfig[k].id
        if (player.p.buyables[id] === undefined) player.p.buyables[id] = new Decimal(0)
    }
}

function getLayerMultiplier(key){
    if(!player.p || player.p[key] === undefined) return new Decimal(1)
    let v = new Decimal(player.p[key])
    if(v.lt(1)) v = new Decimal(1)
    return v
}

// ===== 声望系统 =====

function ensurePrestigeData(){
    if(!player.pt) player.pt = {};
    if(player.pt.unlocked === undefined) player.pt.unlocked = true;
    if(player.pt.points === undefined) player.pt.points = new Decimal(0);
    if(player.pt.pm === undefined) player.pt.pm = new Decimal(1);
    if(player.pt.pe === undefined) player.pt.pe = new Decimal(0);
    if(player.pt.lastScore === undefined) player.pt.lastScore = new Decimal(0);
}

function getPrestigeMult(){
    if(!player.pt || player.pt.pm === undefined) return new Decimal(1);
    let v = new Decimal(player.pt.pm);
    if(v.lt(1)) v = new Decimal(1);
    return v;
}

function getGeneralExponent() {
    if (!player.pt || player.pt.pe === undefined) return new Decimal(1);
    let peVal = new Decimal(player.pt.pe);
    if (inChallenge('inf', 31)) peVal = peVal.div(2);
    let base = new Decimal(1).add(peVal);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 35)) base = base.add(0.01);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 42)) base = base.add(0.02);
    ensureInfinityData();
    if (player.inf.upgrades && player.inf.upgrades.includes(12)) {
        let lvl51 = getStardustBuyableLvl(51);
        base = base.add(0.01).add(new Decimal(0.01).mul(lvl51));
    }
    if (inChallenge('inf', 13)) base = base.sub(0.4);
    if (hasChallenge('inf', 13)) base = base.add(0.03);
    if (base.lt(0)) base = new Decimal(0);
    // u64：通用指数整体 ×1.1
    if (player.inf.upgrades && player.inf.upgrades.includes(64)) {
        base = base.mul(1.1);
    }
    // u73：通用指数整体再次 ×1.1
    if (player.inf.upgrades && player.inf.upgrades.includes(73)) {
        base = base.mul(1.1);
    }
    return base;
}

var PRESTIGE_THRESHOLD = new Decimal(1e10);

function getPrestigeGain(){
    if(!player.points || player.points.lt(PRESTIGE_THRESHOLD)){
        return { pm: new Decimal(1), pe: new Decimal(0) };
    }
    let lgs = player.points.log10();
    
    // pe 软上限
    let peRaw = lgs.sub(5).div(225);
    let pe;
    if (peRaw.gte(2)) {
        let ptsPlus1 = player.points.add(1);
        let inner = ptsPlus1.log10();
        let mid = inner.add(1).log10();
        let outer = mid.log10();
        let offset = new Decimal("1e455").add(1).log10().add(1).log10().log10();
        pe = new Decimal(2).add(outer.sub(offset));
    } else {
        pe = peRaw;
    }
    if(pe.lt(0)) pe = new Decimal(0);
    
    ensureInfinityData();
    let basePM = new Decimal(2.56);
    if (player.inf.upgrades && player.inf.upgrades.includes(15)) {
        basePM = new Decimal(2.70);
    }
    
    let ach34Factor = (typeof hasAchievement === 'function' && hasAchievement('ach', 34)) ? new Decimal(1.01) : new Decimal(1);
    let ach46Factor = new Decimal(1);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 46) && pe.gt(1)) {
        ach46Factor = pe;
    }
    
    let pm;
    if (player.points.gt("1.8e308")) {
        // pm 软上限：1e100 × basePM ^ (ach34Factor × ach46Factor × (lg(lg pts))^2)
        let newExp = ach34Factor.mul(ach46Factor).mul(lgs.log10().pow(2));
        // u71：无限加成 pm 软上限后的指数，公式 lg(无限 + 10)
        if (player.inf.upgrades && player.inf.upgrades.includes(71)) {
            let inf = player.inf.infinity || new Decimal(0);
            newExp = newExp.mul(inf.add(10).log10());
        }
        pm = new Decimal("1e100").mul(basePM.pow(newExp));
    } else {
        let exp = lgs.sub(3).div(2.25).mul(ach34Factor).mul(ach46Factor);
        pm = basePM.pow(exp);
    }
    
    if(pm.lt(1)) pm = new Decimal(1);

    // u72：pe 二次增益（pm 软上限之后生效，对 pm 再做指数提升）
    if (player.inf.upgrades && player.inf.upgrades.includes(72)) {
        if (pe.gte(1.5)) {
            let u72exp;
            if (pe.lt(3)) {
                u72exp = pe.div(1.5);
            } else {
                u72exp = new Decimal(2).mul(pe.sub(2).pow(0.3));
            }
            pm = pm.pow(u72exp);
        }
    }

    if (inChallenge('inf', 21)) pm = pm.pow(0.4);
    if (inChallenge('inf', 31)) pm = pm.div(2);
    if (hasChallenge('inf', 31)) pm = pm.mul(1.2);
    
    return { pm: pm, pe: pe };
}

function canPrestige(){
    if(!player.points) return false;
    if(player.points.lt(PRESTIGE_THRESHOLD)) return false;
    let last = (player.pt && player.pt.lastScore) ? new Decimal(player.pt.lastScore) : new Decimal(0);
    return player.points.gt(last);
}

function doPrestigeReset(){
    if(!canPrestige()) return;
    ensureMultiplierData();
    ensurePrestigeData();

    let gain = getPrestigeGain();
    player.pt.lastScore = new Decimal(player.points);
    player.pt.pm = gain.pm;
    player.pt.pe = gain.pe;

    if (player.auto && player.auto[31]) {
        return;
    }

    player.points = new Decimal(0);
    for (let k of multiplierOrder) player.p[k] = new Decimal(1);
    for (let k of multiplierOrder) player.p.buyables[buyableConfig[k].id] = new Decimal(0);
}

// ===== 晋升系统 =====

function ensureAscensionData(){
    if(!player.prm) player.prm = {};
    if(player.prm.points === undefined) player.prm.points = new Decimal(0);
    if(player.prm.ascended === undefined) player.prm.ascended = false;
    if(!player.prm.buyables) player.prm.buyables = {};
    for (let i = 1; i <= 4; i++){
        if(player.prm.buyables[i] === undefined) player.prm.buyables[i] = new Decimal(0);
    }
}

function getPrmLvl(id){
    ensureAscensionData();
    return new Decimal(player.prm.buyables[id] || 0);
}

function getPrmEffectiveLvl(id){
    let lvl = getPrmLvl(id);
    if (hasChallenge('inf', 21)) lvl = lvl.add(3);
    return lvl;
}

function getPrm4Effect(){
    if (inChallenge('inf', 11)) return new Decimal(1);
    let lvl = getPrmEffectiveLvl(4);
    let exp = (typeof hasAchievement === 'function' && hasAchievement('ach', 33)) ? 0.52 : 0.48;
    if (hasChallenge('inf', 11)) exp += 0.075;
    let base = new Decimal(1).add(new Decimal(0.05).mul(lvl.pow(exp)));
    let ach16Mult = (typeof hasAchievement === 'function' && hasAchievement('ach', 32)) ? new Decimal(1.03) : new Decimal(1);
    let res = base.mul(ach16Mult);
    if (inChallenge('inf', 21)) res = res.pow(0.4);
    if (inChallenge('inf', 31)) res = res.div(2);
    if (hasChallenge('inf', 31)) res = res.mul(1.2);
    if (inChallenge('inf', 22)) {
        let inner = Math.max(10, res.toNumber());
        res = new Decimal(1 + Math.pow(Math.log10(Math.log10(inner)) + 1, 0.2));
    }
    if (hasChallenge('inf', 22)) res = res.mul(1.1);
    if (player.inf.upgrades && player.inf.upgrades.includes(44)) {
        let challCount = getChallengesCompleted();
        res = res.mul(Decimal.pow(5, 0.1 + challCount / 10));
    }
    return res;
}

function getPrm1Effect(){
    let lvl = getPrmEffectiveLvl(1);
    let res = lvl.pow(1.5).add(1).mul(getPrm4Effect());
    if (inChallenge('inf', 21)) res = res.pow(0.4);
    if (inChallenge('inf', 31)) res = res.div(2);
    if (hasChallenge('inf', 31)) res = res.mul(1.2);
    if (inChallenge('inf', 22)) {
        let inner = Math.max(10, res.toNumber());
        res = new Decimal(1 + Math.pow(Math.log10(Math.log10(inner)) + 1, 0.2));
    }
    if (hasChallenge('inf', 22)) res = res.mul(1.1);
    return res;
}

function getPrm2Effect(){
    if (inChallenge('inf', 11)) return new Decimal(1);
    let lvl = getPrmEffectiveLvl(2);
    let exp = 0.5;
    if (hasChallenge('inf', 11)) exp += 0.1;
    let res = new Decimal(1).add(lvl.pow(exp).div(2)).mul(getPrm4Effect());
    if (inChallenge('inf', 21)) res = res.pow(0.4);
    if (inChallenge('inf', 31)) res = res.div(2);
    if (hasChallenge('inf', 31)) res = res.mul(1.2);
    if (inChallenge('inf', 22)) {
        let inner = Math.max(10, res.toNumber());
        res = new Decimal(1 + Math.pow(Math.log10(Math.log10(inner)) + 1, 0.2));
    }
    if (hasChallenge('inf', 22)) res = res.mul(1.1);
    return res;
}

function getPrm3Effect(){
    let lvl = getPrmEffectiveLvl(3);
    let base = (typeof hasAchievement === 'function' && hasAchievement('ach', 34)) ? new Decimal(1.25) : new Decimal(1.2);
    // u61：晋升3效果基础 +0.2
    if (player.inf && player.inf.upgrades && player.inf.upgrades.includes(61)) {
        base = base.add(0.2);
    }
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 36)) {
        let count = 0;
        if (typeof layers !== 'undefined' && layers.ach && layers.ach.achievements) {
            let achConfig = layers.ach.achievements;
            for (let id in achConfig) {
                if (!isNaN(id) && hasAchievement('ach', parseInt(id))) count++;
            }
        }
        base = base.add(new Decimal(count).mul(0.01));
    }
    // u84：生成器倍率加成晋升3基础（立方根，乘数最小为 1）
    if (player.inf && player.inf.upgrades && player.inf.upgrades.includes(84)) {
        let gp = player.inf.gp || new Decimal(0);
        let ge = getEffectiveGE();
        let gpMult = getGPMult(gp, ge);
        let u84mult = new Decimal(1);
        if (gpMult.gt(0)) {
            u84mult = gpMult.log10().add(1).log10().add(1).pow(1/3);
        }
        base = base.mul(u84mult.max(1));
    }
    let res = getPrm4Effect().mul(base.pow(lvl));
    if (inChallenge('inf', 21)) res = res.pow(0.4);
    if (inChallenge('inf', 31)) res = res.div(2);
    if (hasChallenge('inf', 31)) res = res.mul(1.2);
    if (inChallenge('inf', 22)) {
        let inner = Math.max(10, res.toNumber());
        res = new Decimal(1 + Math.pow(Math.log10(Math.log10(inner)) + 1, 0.2));
    }
    if (hasChallenge('inf', 22)) res = res.mul(1.1);
    return res;
}

function getPrmPrice(lvl){
    let base = (typeof hasAchievement === 'function' && hasAchievement('ach', 41)) ? new Decimal(1.88) : new Decimal(2);
    if (hasChallenge('inf', 32)) base = base.sub(0.13);
    return base.pow(lvl);
}

function getAscensionExpGain(){
    if (inChallenge('inf', 32)) return new Decimal(0);
    let pm = getPrestigeMult();
    let nextPm = getPrestigeGain().pm;
    let m = Decimal.max(pm, nextPm);
    let res = m.div(1000).pow(0.75);
    if (inChallenge('inf', 31)) res = res.div(2);
    if (hasChallenge('inf', 31)) res = res.mul(1.2);
    if (player.inf.upgrades && player.inf.upgrades.includes(45)) {
        let challCount = getChallengesCompleted();
        let exp = Decimal.pow(1.5, 0.1 + challCount / 10);
        res = res.pow(exp);
    }
    // u55：晋升经验 ^1.2
    if (player.inf.upgrades && player.inf.upgrades.includes(55)) {
        res = res.pow(1.2);
    }
    // 成就 #47（id 75）：晋升经验获取 ^1.05
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 75)) {
        res = res.pow(1.05);
    }
    // u74：分数加成晋升经验（基于 lg(pts)）
    if (player.inf.upgrades && player.inf.upgrades.includes(74)) {
        if (player.points && player.points.gt("1e3080")) {
            let lgs = player.points.log10();
            let u74exp;
            if (lgs.lte(6160)) {
                u74exp = lgs.div(3080);
            } else {
                u74exp = new Decimal(2).add(lgs.div(6160).sub(1).pow(0.2221));
            }
            res = res.pow(u74exp);
        }
    }
    return res;
}

function canAscend(){
    let pm = getPrestigeMult();
    let nextPm = getPrestigeGain().pm;
    return Decimal.max(pm, nextPm).gte(1000);
}

function doAscend(){
    if(!canAscend()) return;
    ensurePrestigeData();
    ensureAscensionData();
    ensureMultiplierData();
    let gain = getAscensionExpGain();
    player.prm.points = player.prm.points.add(gain);
    player.prm.ascended = true;
    player.pt.pm = new Decimal(1);
    player.pt.pe = new Decimal(0);
    player.pt.lastScore = new Decimal(0);
    player.points = new Decimal(0);
    for (let k of multiplierOrder) player.p[k] = new Decimal(1);
    for (let k of multiplierOrder) player.p.buyables[buyableConfig[k].id] = new Decimal(0);
}

function isAscensionUnlocked(){
    ensureAscensionData();
    if (player.prm.points.gt(0)) return true;
    for (let i = 1; i <= 4; i++) {
        if (player.prm.buyables[i].gt(0)) return true;
    }
    let pm = getPrestigeMult();
    let nextPm = getPrestigeGain().pm;
    return Decimal.max(pm, nextPm).gte(1000);
}

// ===== 无限系统 =====

function ensureInfinityData() {
    if (!player.inf) player.inf = {};
    if (player.inf.points === undefined) player.inf.points = new Decimal(0);
    if (player.inf.infinity === undefined) player.inf.infinity = new Decimal(0);
    if (player.inf.gp === undefined) player.inf.gp = new Decimal(0);
    if (player.inf.ge === undefined) player.inf.ge = new Decimal(0.666);
    if (player.inf.stars === undefined) player.inf.stars = new Decimal(0);
    if (player.inf.stardust === undefined) player.inf.stardust = new Decimal(0);
    if (!player.inf.upgrades) player.inf.upgrades = [];
    if (player.inf.challenge_broken === undefined) player.inf.challenge_broken = false;
    if (player.inf.lastActiveChallenge === undefined) player.inf.lastActiveChallenge = null;
    if (player.inf.lastIPGain === undefined) player.inf.lastIPGain = new Decimal(0);
    if (!player.inf.generators) player.inf.generators = {};
    if (!player.inf.gens) player.inf.gens = {};
    if (!player.inf.buyables) player.inf.buyables = {};
    for (let i = 1; i <= 10; i++) {
        let id = [11, 12, 13, 14, 15, 21, 22, 23, 24, 25][i-1];
        if (player.inf.generators[id] === undefined) player.inf.generators[id] = new Decimal(0);
        if (player.inf.gens[id] === undefined) player.inf.gens[id] = new Decimal(0);
    }
    for (let id of [31, 32, 33, 41, 42, 51, 52]) {
        if (player.inf.buyables[id] === undefined) player.inf.buyables[id] = new Decimal(0);
    }
}

function hardResetAll() {
    ensureMultiplierData();
    ensurePrestigeData();
    ensureAscensionData();
    ensureInfinityData();
    player.points = new Decimal(0);
    player.pt.pm = new Decimal(1);
    player.pt.pe = new Decimal(0);
    player.pt.lastScore = new Decimal(0);
    player.prm.points = new Decimal(0);
    for (let i = 1; i <= 4; i++) player.prm.buyables[i] = new Decimal(0);
    if (player.p) {
        for (let k of multiplierOrder) player.p[k] = new Decimal(1);
        if (player.p.buyables) for (let k of multiplierOrder) player.p.buyables[buyableConfig[k].id] = new Decimal(0);
    }
    player.inf.gp = new Decimal(0);
    player.inf.stardust = new Decimal(0);
    for (let i = 1; i <= 10; i++) {
        let id = [11, 12, 13, 14, 15, 21, 22, 23, 24, 25][i-1];
        player.inf.gens[id] = new Decimal(player.inf.generators[id] || 0);
    }
}

function getInfinityIP(pts) {
    if (!pts || pts.lt("1.7976e308")) return new Decimal(0);
    let lgs = pts.log10();
    let ipGain;
    if (pts.lt("1e3080")) {
        ipGain = lgs.div(308);
    } else {
        ipGain = new Decimal(10).mul(Decimal.pow(10, lgs.div(308).sub(10)));
    }
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 53)) ipGain = ipGain.mul(2);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 62)) ipGain = ipGain.mul(2.25);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 73)) ipGain = ipGain.mul(1.2);
    let challCount = getChallengesCompleted();
    ipGain = ipGain.mul(1 + challCount);
    if (hasChallenge('inf', 31)) ipGain = ipGain.mul(1.2);
    if (hasChallenge('inf', 33)) ipGain = ipGain.mul(2);
    if (player.inf.upgrades) {
        let upgs = player.inf.upgrades;
        if (upgs.includes(41)) {
            ipGain = ipGain.mul(Decimal.pow(3, 0.1 + challCount / 10));
        }
        if (upgs.includes(43)) {
            let inf = player.inf.infinity || new Decimal(0);
            ipGain = ipGain.mul(new Decimal(1).add(inf.pow(0.1)));
        }
        if (upgs.includes(52)) {
            let p = pts;
            if (p.lt(1)) p = new Decimal(1);
            ipGain = ipGain.mul(p.log10().add(10).pow(0.2221));
        }
    }
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 76)) ipGain = ipGain.mul(2);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 81)) ipGain = ipGain.mul(1.5);
    // IP 硬上限 1.8e308
    if (ipGain.gt("1.8e308")) ipGain = new Decimal("1.8e308");
    return ipGain;
}

function getInfinityGain() {
    if (!player.points || player.points.lt("1.7976e308")) return new Decimal(0);
    let infGain = new Decimal(1);
    if (hasChallenge('inf', 33)) infGain = infGain.mul(2);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 66)) infGain = infGain.mul(1.5);
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 74)) infGain = infGain.mul(1.1);
    if (player.inf.upgrades && player.inf.upgrades.includes(53)) {
        let pts = player.points;
        if (pts.gt(10)) {
            let lgs = pts.log10();
            if (lgs.gt(1)) {
                let lgLg = lgs.log10();
                if (lgLg.gt(0)) {
                    infGain = infGain.mul(lgLg.pow(0.67));
                }
            }
        }
    }
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 76)) infGain = infGain.mul(2);
    // 星尘购买项42：无限获取 ×(1 + 等级)
    let lvl42 = getStardustBuyableLvl(42);
    if (lvl42.gt(0)) infGain = infGain.mul(new Decimal(1).add(lvl42));
    // 成就 #54（id 85）：无限获取 ×1.5
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 85)) infGain = infGain.mul(1.5);
    return infGain;
}

function doInfinityReset() {
    if (!player.points || player.points.lt("1.7976e308")) return;
    ensureInfinityData();
    let ipGain = getInfinityIP(player.points);
    player.inf.points = player.inf.points.add(ipGain);
    if (player.inf.points.gt("1.8e308")) player.inf.points = new Decimal("1.8e308");
    player.inf.lastIPGain = ipGain;
    player.inf.infinity = player.inf.infinity.add(getInfinityGain());
    hardResetAll();
}

// ===== 其他 =====

function getScoreProduct(){
    let prod = new Decimal(1)
    for (let k of multiplierOrder){
        prod = prod.mul(getLayerMultiplier(k))
    }
    prod = prod.mul(getPrestigeMult())
    return prod
}

function getScoreGain(){
    ensureAscensionData();
    ensureInfinityData();
    let baseGain = getScoreProduct().mul(getPrm3Effect()).pow(getGeneralExponent());
    if (player.inf.upgrades) {
        let upgBase = (typeof hasAchievement === 'function' && hasAchievement('ach', 65)) ? new Decimal(10) : new Decimal(2);
        baseGain = baseGain.mul(upgBase.pow(player.inf.upgrades.length));
        
        if (player.inf.upgrades.includes(11)) {
            let inf = player.inf.infinity || new Decimal(1);
            if (inf.lt(1)) inf = new Decimal(1);
            baseGain = baseGain.mul(inf);
        }
    }
    if (typeof hasAchievement === 'function' && hasAchievement('ach', 65)) {
        baseGain = baseGain.mul(10);
    }
    if (player.inf.upgrades && player.inf.upgrades.includes(75)) {
        let xp = (player.prm && player.prm.points) || new Decimal(0);
        if (xp.gt(1)) {
            let xpExp;
            if (xp.lte("1.8e308")) {
                xpExp = new Decimal(0.7);
            } else {
                let prm4 = getPrm4Effect();
                xpExp = new Decimal(0.7).add(new Decimal(0.1).mul(prm4.add(1).log10()));
                if (xpExp.gt(5)) xpExp = new Decimal(5);
            }
            baseGain = baseGain.mul(xp.pow(xpExp));
        }
    }
    return baseGain;
}

function getMultiplierDisplay(){
    ensureMultiplierData()
    ensureAscensionData()
    ensureInfinityData()

    let prm3 = getPrm3Effect();
    let prm3Str = '';
    if (prm3.gt(1)) prm3Str = ' * ' + `<span style="color:#4bdc13">${format(prm3)}</span>`;

    let s = '<div class="overlayThing">'
    s += '<div class="overlayThing">当前分数获取：('
    s += multiplierOrder.map(k => `<span style="color:${multiplierColors[k]}">${format(getLayerMultiplier(k))}</span>`).join('*')
    s += '*' + `<span style="color:${prestigeMultColor}">${format(getPrestigeMult())}</span>`
    s += prm3Str
    s += ')^' + `<span style="color:${generalExponentColor}">${format(getGeneralExponent())}</span>`
    s += ' = ' + format(getScoreGain()) + '/s</div>'

    let pts = player.points || new Decimal(0);
    if (pts.lt(1)) pts = new Decimal(1);
    let lgs = pts.log10();
    if (!(lgs instanceof Decimal)) lgs = new Decimal(lgs);
    let progressStr = "";
    let progressColor = "#ff66dd";

    let ip = (player.inf && player.inf.points) || new Decimal(0);
    if (ip.gte(1e154)) {
        let ipSafe = ip.max(1);
        let eterProgress = ipSafe.log10().div(308.25).mul(100).toNumber();
        progressStr = `永恒进度：${eterProgress.toFixed(4)}%`;
        progressColor = "#1992fe";
    } else if (pts.lt("1.8e308")) {
        let infProgress = lgs.div(308.25471556).mul(100).toNumber();
        progressStr = `无限进度：${infProgress.toFixed(4)}%`;
    } else if (pts.lt("1e3080")) {
        let ipProgress = lgs.div(308).log10().mul(100).toNumber();
        progressStr = `无限点数*10进度：${ipProgress.toFixed(4)}%`;
    } else {
        let q = lgs.div(308);
        let frac = q.sub(q.floor());
        let ipProgress = frac.mul(100).toNumber();
        progressStr = `IP*10 progress：${ipProgress.toFixed(4)}%`;
    }

    s += `<div class="overlayThing" style="color:${progressColor}; margin-top: 4px;">${progressStr}</div>`
    return s
}

function getMultiplierList() {
	ensureMultiplierData()
	let s = '<div class="overlayThing">'
	s += '<div style="font-size:22px;margin-bottom:8px;">乘数数量</div>'
	s += '<div style="display:flex;flex-wrap:wrap;gap:10px 18px;align-items:center;">'
	s += multiplierOrder.map(k => {
		let c = multiplierColors[k]
		return `<div style="white-space:nowrap;">
            ${multiplierNames[k]}：
            <span style="color:${c};font-weight:bold;">x${format(getLayerMultiplier(k))}</span>
        </div>`
	}).join('')
	s += `<div style="white-space:nowrap;">
        声望乘数：
        <span style="color:${prestigeMultColor};font-weight:bold;">x${format(getPrestigeMult())}</span>
    </div>`
	s += `<div style="white-space:nowrap;">
        通用指数：
        <span style="color:${generalExponentColor};font-weight:bold;">${format(getGeneralExponent())}</span>
    </div>`
	s += '</div>'
	s += '</div>'
	return s
}

function getPointGen() {
	if(!canGenPoints()) return new Decimal(0)
    ensureMultiplierData()
    ensurePrestigeData()
    ensureAscensionData()
    let gain = getScoreGain();
    if (inChallenge('inf', 23)) gain = gain.div(5);
    if (!player.inf || !player.inf.challenge_broken) {
        if (player.points && player.points.gte(MAX_POINTS)) return new Decimal(0);
    }
    return gain;
}

function addedPlayerData() { return {} }

var displayThings = [
	function() {
		if(options.ch==undefined && modInfo.internationalizationMod==true){return '<big><br>You should choose your language first<br>你需要先选择语言</big>'}
		return '<div class="res">'+displayThingsRes()+'</div><br><div class="vl2"></div></span>'
	}
]

function displayThingsRes(){
	return 'Points: '+format(player.points)+' | '
}

function isEndgame() {
	return player.inf && player.inf.points.gte("1.8e308");
}

function getPointsDisplay(){
	let a = ''
	if(player.devSpeed && player.devSpeed!=1){
		a += options.ch ? '<br>时间加速: '+format(player.devSpeed)+'x' : '<br>Dev Speed: '+format(player.devSpeed)+'x'
	}
	if(player.offTime!==undefined){
		a += options.ch ? '<br>离线加速剩余时间: '+formatTime(player.offTime.remain) : '<br>Offline Time: '+formatTime(player.offTime.remain)
	}
	a += '<br>'
	if(!(options.ch==undefined && modInfo.internationalizationMod==true)){
		a += `<span class="overlayThing">${(i18n("你有", "You have", false))} <h2 class="overlayThing" id="points"> ${format(player.points)}</h2> ${i18n(modInfo.pointsName, modInfo.pointsNameI18N)}</span>`
		if(canGenPoints()){
			a += `<br><span class="overlayThing">(`+(tmp.other.oompsMag != 0 ? format(tmp.other.oomps) + " OoM" + (tmp.other.oompsMag < 0 ? "^OoM" : tmp.other.oompsMag > 1 ? "^" + tmp.other.oompsMag : "") + "s" : formatSmall(getPointGen()))+`/sec)</span>`
		}
		a += `<div style="margin-top: 3px"></div>`
		a += getMultiplierDisplay()
	}
	a += tmp.displayThings
	a += '<br><br>'
	return a
}

var backgroundStyle = {}
function maxTickLength() { return(3600) }

function fixOldSave(oldVersion) {
    ensureMultiplierData()
    ensurePrestigeData()
    ensureAscensionData()
    ensureInfinityData()
    if (!player.inf || !player.inf.challenge_broken) {
        if (player.points && player.points.gt(MAX_POINTS)) {
            player.points = new Decimal(MAX_POINTS);
        }
    }
    if (player.inf && player.inf.points && player.inf.points.gt("1.8e308")) {
        player.inf.points = new Decimal("1.8e308");
    }
}